@echo off
title Dong goi Ung dung Windows DungMau.exe
echo ============================================================
echo   DUNGMAU (DUNGMAU.VN) - DONG GOI PHAN MEM WINDOWS (.EXE)
echo ============================================================
echo.
echo [1/3] Cai dat thu vien can thiet...
call npm install
echo.
echo [2/3] Bien dich giao dien & dong goi file DungMau.exe kem Icon...
call npx tauri build
echo.
echo [3/3] Tao thu muc phan phoi Portable de nen ZIP gui khach...
if not exist "Release_DungMau_Windows" mkdir "Release_DungMau_Windows"
copy /Y "src-tauri\target\release\DungMau.exe" "Release_DungMau_Windows\DungMau.exe" >nul
if exist "src-tauri\target\release\WebView2Loader.dll" copy /Y "src-tauri\target\release\WebView2Loader.dll" "Release_DungMau_Windows\WebView2Loader.dll" >nul
echo.
echo HOAN TAT! Hay nen thu muc "Release_DungMau_Windows" thanh file .ZIP gui cho khach hang.
pause
