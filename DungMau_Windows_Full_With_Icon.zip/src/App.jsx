import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Clapperboard, ShoppingBag, Radio, Camera, BookOpen, Sparkles, Copy, Check,
  Play, Pause, RotateCcw, Download, Lock, Crown, ShieldCheck, User, LogOut,
  History, Trash2, Moon, Sun, AlertTriangle, CheckCircle2, ChevronRight,
  ChevronDown, Eye, EyeOff, KeyRound, FileText, Package, Sliders, X,
  Smartphone, Monitor, Film, Aperture, Palette, Zap, Award, Users, Info
} from 'lucide-react';

// ============================================================================
// 1. CẤU HÌNH THƯƠNG HIỆU & PHÂN TẦNG GÓI CƯỚC (DỰNGMẪU - DUNGMAU.VN)
// ============================================================================
const BRAND = {
  name: 'DựngMẫu',
  domain: 'DungMau.vn',
  tagline: 'Dựng kịch bản chuẩn — Tạo mẫu như thật',
  supportEmail: 'hotro@dungmau.vn',
  bankInfo: {
    bankId: 'MB',
    accountNo: '888866669999',
    accountName: 'CONG TY TNHH CONG NGHE DUNG MAU'
  }
};

const PLANS = {
  FREE: {
    id: 'FREE',
    name: 'Trải Nghiệm',
    badge: 'MIỄN PHÍ',
    priceMonthly: 0,
    priceYearly: 0,
    credits: 3,
    maxDuration: 30,
    maxHistory: 3,
    allowAllTikTokAngles: false,
    allowShopeeAutoClean: false,
    allowFullLiveObjections: false,
    allowFullTeleprompter: false,
    allowTxtExport: false,
    allowAllInOneExport: false,
    desc: 'Dùng thử trọn bộ câu lệnh tạo người mẫu & kịch bản 30 giây.'
  },
  STARTER: {
    id: 'STARTER',
    name: 'Chủ Shop Nhỏ',
    badge: 'STARTER',
    priceMonthly: 79000,
    priceYearly: 59000,
    credits: 25,
    maxDuration: 45,
    maxHistory: 30,
    allowAllTikTokAngles: true,
    allowShopeeAutoClean: true,
    allowFullLiveObjections: true,
    allowFullTeleprompter: true,
    allowTxtExport: false,
    allowAllInOneExport: false,
    desc: 'Mở đủ 3 góc kịch bản TikTok 45s, lọc từ cấm Shopee & máy nhắc chữ.'
  },
  PRO: {
    id: 'PRO',
    name: 'Đạo Diễn Bán Hàng',
    badge: 'PRO',
    priceMonthly: 199000,
    priceYearly: 149000,
    credits: 9999,
    maxDuration: 90,
    maxHistory: 200,
    allowAllTikTokAngles: true,
    allowShopeeAutoClean: true,
    allowFullLiveObjections: true,
    allowFullTeleprompter: true,
    allowTxtExport: true,
    allowAllInOneExport: false,
    popular: true,
    desc: 'Không giới hạn lượt tạo, kịch bản dài 60s–90s & xuất file kịch bản.'
  },
  AGENCY: {
    id: 'AGENCY',
    name: 'Chuỗi Shop & Studio',
    badge: 'AGENCY',
    priceMonthly: 499000,
    priceYearly: 379000,
    credits: 9999,
    maxDuration: 90,
    maxHistory: 1000,
    allowAllTikTokAngles: true,
    allowShopeeAutoClean: true,
    allowFullLiveObjections: true,
    allowFullTeleprompter: true,
    allowTxtExport: true,
    allowAllInOneExport: true,
    desc: 'Xuất trọn bộ 4 kênh trong 1 tệp duy nhất cho đội ngũ quay dựng.'
  }
};

// Danh sách từ vi phạm chính sách sàn TMĐT Việt Nam & từ thay thế an toàn
const BANNED_WORDS_MAP = [
  { word: 'cam kết 100%', replace: 'hỗ trợ tối ưu hiệu quả' },
  { word: 'chữa khỏi', replace: 'cải thiện rõ rệt' },
  { word: 'trị dứt điểm', replace: 'giảm thiểu tình trạng' },
  { word: 'rẻ nhất', replace: 'giá tốt hàng đầu' },
  { word: 'tốt nhất', replace: 'chất lượng vượt trội' },
  { word: 'số 1', replace: 'được nhiều khách tin chọn' },
  { word: 'hoàn tiền 100%', replace: 'đổi trả theo chính sách sàn' },
  { word: 'zalo', replace: 'kênh chat của shop' },
  { word: 'facebook', replace: 'trang chính thức của shop' },
  { word: 'chuyển khoản ngoài', replace: 'thanh toán trực tiếp trên sàn' },
  { word: 'thuốc', replace: 'sản phẩm hỗ trợ' }
];

// 3 Sản phẩm mẫu thực chiến để test 1 chạm
const SAMPLE_PRODUCTS = [
  {
    label: 'Nồi chiên không dầu 6L',
    name: 'Nồi chiên không dầu mặt kính 6L lòng gốm chống dính',
    category: 'Gia dụng & Nhà bếp',
    price: '890.000đ (Giảm từ 1.350.000đ)',
    usp: 'Mặt kính cường lực nhìn rõ thức ăn bên trong, lòng nồi phủ gốm không bong tróc, dung tích 6L nướng nguyên con gà 1.8kg',
    audience: 'Mẹ bỉm sữa, dân văn phòng bận rộn 24-38 tuổi',
    tone: 'Chân thực, đời thường (Review thật)',
    duration: 30,
    modelPersona: 'Nữ Việt Nam 27 tuổi, gương mặt phúc hậu, tóc buộc nửa đầu tự nhiên',
    beautyStyle: 'Nàng thơ trong trẻo, ngũ quan hài hòa',
    makeupStyle: 'Trang điểm trong suốt tự nhiên (No-makeup)',
    setting: 'Bếp căn hộ chung cư Việt Nam ấm cúng, ánh sáng cửa sổ buổi sáng',
    cameraFeel: 'iPhone 15 Pro quay cầm tay chân thực (UGC)',
    aspectRatio: '9:16',
    extraDetail: 'Tay cầm quai nồi chắc chắn, hơi nước bốc nhẹ qua mặt kính, trên bàn bếp có đĩa khoai tây vàng giòn'
  },
  {
    label: 'Áo thun Boxy Cotton 250gsm',
    name: 'Áo thun nam nữ form Boxy vải Cotton 2 chiều 250gsm dày dặn',
    category: 'Thời trang & Phụ kiện',
    price: '179.000đ (Mua 2 giảm thêm 20k)',
    usp: 'Vải cotton định lượng 250gsm đứng form không lộ khuyết điểm, cổ bo dệt dày không bai dão sau 50 lần giặt',
    audience: 'Gen Z, sinh viên, người thích mặc đồ tối giản 18-28 tuổi',
    tone: 'Bắt trend, dứt khoát, đánh vào nỗi đau',
    duration: 30,
    modelPersona: 'Nữ Việt Nam 22 tuổi, dáng thanh mảnh, phong cách năng động',
    beautyStyle: 'Hotgirl hiện đại, đường nét sắc sảo cuốn hút',
    makeupStyle: 'Trang điểm nhẹ kiểu Hàn Quốc căng bóng',
    setting: 'Góc ban công quán cà phê phố cổ Hà Nội / Sài Gòn có nắng xiên',
    cameraFeel: 'Sony A7R V ống kính 85mm f/1.4 xóa phông mượt',
    aspectRatio: '9:16',
    extraDetail: 'Thấy rõ từng thớ dệt vải cotton dày, nếp gấp tự nhiên ở khuỷu tay, ánh nắng chiếu tạo viền tóc óng mượt'
  },
  {
    label: 'Bàn chải điện sóng âm',
    name: 'Bàn chải điện sóng âm 42.000 nhịp/phút pin 60 ngày chống nước IPX7',
    category: 'Chăm sóc cá nhân & Làm đẹp',
    price: '249.000đ (Tặng kèm 4 đầu chải)',
    usp: 'Làm sạch mảng bám gấp 5 lần bàn chải thường, 5 chế độ rung êm không chảy máu chân răng, sạc 1 lần dùng 2 tháng',
    audience: 'Người niềng răng, nhân viên văn phòng hay uống cà phê 22-40 tuổi',
    tone: 'Chuyên gia phân tích & So sánh trực diện',
    duration: 45,
    modelPersona: 'Nam Việt Nam 26 tuổi, nụ cười rạng rỡ, hàm răng trắng đều tự nhiên',
    beautyStyle: 'Nam thần điển trai, góc hàm sắc nét, thân thiện',
    makeupStyle: 'Mặt mộc khỏe khoắn, làn da nam tính tự nhiên',
    setting: 'Phòng tắm hiện đại ốp gạch sáng màu, gương soi có đèn LED dịu',
    cameraFeel: 'Máy quay Cinema 35mm ánh sáng tự nhiên',
    aspectRatio: '9:16',
    extraDetail: 'Cầm thân bàn chải bằng 3 ngón tay tự nhiên, bọt kem đánh răng mịn nhẹ, ánh sáng phản chiếu trong đồng tử mắt'
  }
];

// ============================================================================
// 2. BỘ SINH DỮ LIỆU KỊCH BẢN & CÂU LỆNH NGƯỜI MẪU SIÊU THỰC
// ============================================================================
function buildCampaignData(form) {
  const {
    name, category, price, usp, audience, tone, duration,
    modelPersona, beautyStyle, makeupStyle, setting, cameraFeel, aspectRatio, extraDetail
  } = form;

  const shortName = name.split(' ').slice(0, 6).join(' ');
  const uspList = usp.split(',').map((s) => s.trim()).filter(Boolean);
  const usp1 = uspList[0] || 'thiết kế tối ưu trải nghiệm sử dụng hằng ngày';
  const usp2 = uspList[1] || 'độ bền vượt trội, tiết kiệm chi phí lâu dài';
  const usp3 = uspList[2] || 'mức giá ưu đãi trực tiếp từ xưởng';

  // Tạo các phân cảnh TikTok khớp chi tiết từng giây theo đúng thời lượng chọn
  const buildScenes = (angleType) => {
    if (duration === 15) {
      return [
        {
          time: '00:00 - 00:03',
          sec: 3,
          camera: 'Cận cảnh 45° — Đẩy máy nhanh (Whip Zoom)',
          action: 'Cầm trực tiếp sản phẩm đưa sát ống kính, biểu cảm ngạc nhiên thật',
          voice: angleType === 'pain'
            ? `Đừng mua ${shortName} nếu bạn chưa xem hết 15 giây này!`
            : angleType === 'compare'
            ? `Cùng bỏ ra ${price.split('(')[0].trim()} nhưng khác biệt một trời một vực!`
            : `Dùng hết 2 tuần rồi mới dám lên video nhận xét thật về em này.`,
          overlay: angleType === 'pain' ? 'KHOAN ĐÃ! XEM HẾT 15S' : 'SO SÁNH THỰC TẾ 100%',
          sfx: 'Tiếng Bass Drop + Whoosh nhẹ'
        },
        {
          time: '00:03 - 00:11',
          sec: 8,
          camera: 'Góc trung ngang tầm mắt — Cắt cảnh nhanh mỗi 2 giây',
          action: `Thao tác thực tế chứng minh: ${usp1} và ${usp2}`,
          voice: `Điểm ăn tiền nhất là ${usp1}. Thêm quả ${usp2} nên dùng sướng hơn hẳn loại cũ ở nhà.`,
          overlay: `✓ ${usp1.slice(0, 38)}...`,
          sfx: 'Nhạc nền nhịp nhanh 120 BPM'
        },
        {
          time: '00:11 - 00:15',
          sec: 4,
          camera: 'Cận cảnh sản phẩm + Chỉ tay góc trái dưới',
          action: 'Gật đầu dứt khoát, chỉ tay thẳng vào vị trí giỏ hàng vàng',
          voice: `Đang có trợ giá ${price}, bấm giỏ hàng góc trái kẻo hết suất nhé!`,
          overlay: `GIÁ HỜI: ${price.split('(')[0].trim()} 👇`,
          sfx: 'Tiếng Ting chốt đơn'
        }
      ];
    }

    const baseScenes = [
      {
        time: '00:00 - 00:03',
        sec: 3,
        camera: 'Cận cảnh khuôn mặt + Sản phẩm (50mm, ngang tầm mắt)',
        action: 'Nhìn thẳng ống kính, giơ sản phẩm lên ngang vai tạo điểm dừng thị giác',
        voice: angleType === 'pain'
          ? `Từng mất tiền oan 3 lần trước khi tìm ra chân ái ${shortName} này!`
          : angleType === 'compare'
          ? `Đặt cạnh hàng trôi nổi ngoài chợ mới thấy tại sao ${shortName} cháy hàng liên tục.`
          : `Người thật việc thật: Mình đã dùng ${shortName} liên tục cho ${audience} và đây là kết quả.`,
        overlay: angleType === 'pain' ? 'ĐỪNG MẤT TIỀN OAN NỮA!' : 'KIỂM CHỨNG THỰC TẾ',
        sfx: 'Tiếng Pop + Nhịp trống mở đầu'
      },
      {
        time: '00:03 - 00:12',
        sec: 9,
        camera: 'Góc nghiêng 3/4 — Quay chi tiết bề mặt chất liệu (Macro)',
        action: `Xoay 360 độ sản phẩm dưới ánh sáng tự nhiên, chỉ rõ ${usp1}`,
        voice: `Nhìn kỹ chi tiết này nhé: ${usp1}. Đây là thứ quyết định độ bền mà ít người bán nói cho bạn biết.`,
        overlay: `ĐIỂM MẠNH 1: ${usp1.slice(0, 42)}`,
        sfx: 'Nhạc nền Lofi/Beat nhẹ tôn giọng nói'
      },
      {
        time: '00:12 - 00:24',
        sec: 12,
        camera: 'Toàn cảnh thao tác sử dụng thực tế trong bối cảnh đời thường',
        action: `Sử dụng trực tiếp sản phẩm trước ống kính để kiểm chứng ${usp2}`,
        voice: `Khi đưa vào dùng thực tế mỗi ngày, ${usp2}. Cảm giác cầm nắm và vận hành cực kỳ chắc tay, không hề ọp ẹp.`,
        overlay: `TEST THỰC TẾ: ${usp2.slice(0, 42)}`,
        sfx: 'Âm thanh thật của sản phẩm (ASMR)'
      },
      {
        time: '00:24 - 00:30',
        sec: 6,
        camera: 'Cận cảnh biểu cảm hài lòng + Chỉ tay giỏ hàng góc trái',
        action: 'Mỉm cười tự nhiên, chỉ tay rõ ràng xuống nút Giỏ hàng vàng',
        voice: `Hôm nay gian hàng chính hãng đang trợ giá chỉ ${price}. Bấm ngay giỏ hàng góc trái trước khi về giá gốc nhé!`,
        overlay: `ƯU ĐÃI HÔM NAY: ${price}`,
        sfx: 'Tiếng chuông Ting + Nhạc đẩy cao trào'
      }
    ];

    if (duration >= 45) {
      baseScenes.splice(3, 0, {
        time: '00:24 - 00:39',
        sec: 15,
        camera: 'Chia đôi khung hình (Split Screen) Trước & Sau khi dùng',
        action: `Đối chiếu trực tiếp kết quả thực tế dành riêng cho ${audience}`,
        voice: `Đặc biệt nếu bạn thuộc nhóm ${audience}, dùng xong sẽ thấy tiết kiệm được bao nhiêu thời gian và công sức. Chưa kể ${usp3}.`,
        overlay: 'TRƯỚC & SAU KHI DÙNG',
        sfx: 'Tiếng chuyển cảnh Whoosh'
      });
      baseScenes[4].time = '00:39 - 00:45';
    }

    if (duration >= 60) {
      baseScenes.splice(4, 0, {
        time: '00:39 - 00:53',
        sec: 14,
        camera: 'Góc cận phản hồi thắc mắc thường gặp của khách mua',
        action: 'Giơ 2 ngón tay liệt kê chính sách bảo hành & kiểm tra hàng',
        voice: `Nhiều bạn hỏi có được kiểm tra hàng và bảo hành không? Shop hỗ trợ đổi trả minh bạch trên sàn nên cứ yên tâm trải nghiệm.`,
        overlay: 'ĐỔI TRẢ MINH BẠCH TRÊN SÀN',
        sfx: 'Nhạc nền giữ nhịp ổn định'
      });
      baseScenes[5].time = duration === 90 ? '00:78 - 00:90' : '00:53 - 00:60';
      baseScenes[5].sec = duration === 90 ? 12 : 7;
    }

    if (duration === 90) {
      baseScenes.splice(5, 0, {
        time: '00:53 - 01:18',
        sec: 25,
        camera: 'Kể chuyện tình huống thực tế (Storytelling) tại nhà/văn phòng',
        action: 'Mô phỏng tình huống thực tế lúc bận rộn và cách sản phẩm giải quyết gọn gàng',
        voice: `Hôm qua nhà có việc gấp, nhờ có ${shortName} mà xử lý gọn trong vài phút. Tính ra chia nhỏ chi phí mỗi ngày chưa tới một cốc trà đá mà nhàn hơn hẳn.`,
        overlay: 'TÍNH RA CHƯA TỚI 1 CỐC TRÀ ĐÁ/NGÀY',
        sfx: 'Nhạc nền cảm xúc nhẹ nhàng'
      });
      baseScenes[6].time = '01:18 - 01:30';
    }

    return baseScenes;
  };

  const tiktokScripts = [
    {
      id: 'angle-1',
      title: 'Góc 1: Đánh trúng nỗi đau & Sự thật mất lòng',
      badge: 'Tỷ lệ giữ chân cao nhất',
      hookRate: 'Ước tính giữ chân 3s đầu: 74%',
      scenes: buildScenes('pain')
    },
    {
      id: 'angle-2',
      title: 'Góc 2: So sánh trực diện hàng thường vs Hàng chuẩn',
      badge: 'Chốt đơn khách kỹ tính',
      hookRate: 'Ước tính giữ chân 3s đầu: 68%',
      scenes: buildScenes('compare')
    },
    {
      id: 'angle-3',
      title: 'Góc 3: Đập hộp & Trải nghiệm thực tế đời thường (UGC)',
      badge: 'Chạy quảng cáo chuyển đổi tốt',
      hookRate: 'Ước tính giữ chân 3s đầu: 71%',
      scenes: buildScenes('ugc')
    }
  ];

  // Tạo bộ SEO Shopee chuẩn thuật toán tìm kiếm
  const seoTitle = `[CHÍNH HÃNG] ${name} - ${usp1.charAt(0).toUpperCase() + usp1.slice(1)} Dành Cho ${audience.split(',')[0]}`.slice(0, 120);
  const seoDescription = `🔥 ${name.toUpperCase()} — LỰA CHỌN HÀNG ĐẦU CHO ${audience.toUpperCase()}

✅ TẠI SAO NÊN CHỌN SẢN PHẨM NÀY?
• ${usp1.charAt(0).toUpperCase() + usp1.slice(1)}.
• ${usp2.charAt(0).toUpperCase() + usp2.slice(1)}.
• ${usp3.charAt(0).toUpperCase() + usp3.slice(1)}.

📋 THÔNG TIN CHI TIẾT SẢN PHẨM:
• Tên sản phẩm: ${name}
• Ngành hàng: ${category}
• Đối tượng phù hợp: ${audience}
• Quy cách đóng gói: Hộp chống sốc 3 lớp nguyên seal, đầy đủ phụ kiện đi kèm.

🛡️ CHÍNH SÁCH BÁN HÀNG & BẢO HÀNH:
• Hỗ trợ đổi trả miễn phí trong 15 ngày nếu có lỗi từ nhà sản xuất (vui lòng quay video mở hộp để được xử lý nhanh nhất).
• Giao hàng hỏa tốc nội thành và giao toàn quốc từ 2-4 ngày.
• Lưu ý: Sản phẩm cam kết 100% đúng mô tả, hỗ trợ tư vấn 24/7 (không giao dịch qua zalo hay chuyển khoản ngoài sàn để bảo vệ quyền lợi khách hàng).

#ShopeeVN #HangChinhHang #${category.replace(/[^a-zA-Z0-9]/g, '')} #GiaTotHomNay #ReviewChanThuc`;

  const seoKeywords = [
    name.toLowerCase(),
    `${shortName.toLowerCase()} chính hãng`,
    `${shortName.toLowerCase()} giá tốt`,
    `mua ${shortName.toLowerCase()}`,
    `${category.toLowerCase()} tiện ích`,
    `${shortName.toLowerCase()} bền đẹp`
  ];

  // Kịch bản Livestream 4 chặng
  const livestreamScript = {
    stages: [
      {
        time: 'Phút 00:00 - 02:00',
        title: 'Chặng 1: Kéo mắt xem & Ghim mã giảm giá',
        script: `"Chào cả nhà vừa vào phiên live nhé! Ai đang tìm ${shortName} chuẩn bền thì nán lại đúng 2 phút, hôm nay shop tung deal ${price} duy nhất trên phiên live này. Cả nhà thả tim và bình luận 'Săn deal' để em ghim ngay giỏ hàng số 1 cho mình ạ!"`
      },
      {
        time: 'Phút 02:00 - 05:00',
        title: 'Chặng 2: Trình diễn trực tiếp & Chứng minh chất lượng',
        script: `"Đây, em quay sát camera cho mọi người nhìn rõ chất thật luôn nhé! Điểm khác biệt lớn nhất của mẫu này là ${usp1}. Không phải hàng mỏng nhẹ dùng vài bữa đâu ạ, ${usp2}. Em thử trực tiếp ngay trên live cho các bác xem độ thực tế."`
      },
      {
        time: 'Phút 05:00 - 08:00',
        title: 'Chặng 3: Báo giá hời & Tạo khan hiếm thật',
        script: `"Giá niêm yết bình thường là giá gốc, nhưng riêng 15 suất đầu tiên bấm mua trong live hôm nay chỉ còn ${price}. Em thấy hệ thống báo chỉ còn đúng 6 suất trợ giá cuối cùng thôi ạ!"`
      },
      {
        time: 'Phút 08:00 - 10:00',
        title: 'Chặng 4: Thúc đẩy chốt đơn & Chuyển sang mã tiếp theo',
        script: `"Cảm ơn chị Lan, anh Tuấn đã chốt đơn thành công trên giỏ số 1 nhé! Còn đúng 30 giây nữa em xin phép tắt mã trợ giá này để chuyển sang sản phẩm tiếp theo. Bác nào còn phân vân bấm thanh toán ngay để giữ mã freeship nhé!"`
      }
    ],
    objections: [
      {
        question: 'Khách hỏi: "Sao giá cao hơn mấy shop khác trên sàn vậy?"',
        answer: `"Dạ em cảm ơn câu hỏi rất thực tế ạ! Nhìn ảnh thì giống nhau nhưng cầm trên tay mới thấy khác hẳn ở phần ${usp1}. Shop em bảo hành đổi trả minh bạch trên sàn, tính ra dùng bền gấp 3 lần thì lại thành rẻ hơn nhiều ạ."`
      },
      {
        question: 'Khách hỏi: "Hàng nhận về có giống y như trên live không?"',
        answer: `"Dạ cam kết hình ảnh quay bằng camera thường ngay trên live thế nào thì bác nhận về y hệt thế ấy. Khi nhận hàng bác cứ quay lại video mở hộp, nếu sai một chi tiết nhỏ shop hoàn tiền ngay qua sàn ạ."`
      },
      {
        question: 'Khách hỏi: "Có được miễn phí vận chuyển không shop?"',
        answer: `"Dạ có ạ! Bác bấm vào nút Mua ngay ở giỏ hàng số 1, sau đó chọn mục Shopee Voucher / TikTok Voucher tích sẵn mã Freeship Xtra của sàn là được giảm thẳng phí ship ngay bước thanh toán nhé!"`
      },
      {
        question: 'Khách hỏi: "Để suy nghĩ thêm đã..."',
        answer: `"Dạ vâng bác cứ cân nhắc thoải mái ạ, nhưng em nhắc nhẹ là mã trợ giá ${price} chỉ áp dụng tự động trong lúc đèn live còn sáng thôi, tắt live là hệ thống tự nhảy về giá gốc nên bác bấm giữ đơn trước cho đỡ tiếc nhé!"`
      }
    ]
  };

  // Bộ 4 câu lệnh dựng ảnh & video người mẫu siêu thực (Hyper-Realistic RAW)
  const negativePrompt =
    'plastic skin, airbrushed face, CGI, 3D render, doll-like, overly smooth skin, asymmetrical eyes, cross-eyed, uncanny valley, distorted teeth, extra fingers, 6 fingers, fused fingers, deformed hands, floating product, warped text on packaging, harsh flash shadow under nose, wide-angle facial distortion, watermark, logo overlay, cartoon, anime, illustration';

  const modelPrompts = [
    {
      id: 'prompt-1',
      title: 'Mẫu 1: Đời thực cầm tay (UGC Chân thực như khách tự quay)',
      badge: 'Khuyên dùng chạy Ads & TikTok',
      tool: 'Midjourney v6.1 / Flux.1 Dev / Gemini Imagen 3',
      viExplain:
        'Tái tạo khung hình tự nhiên như người dùng thật cầm điện thoại tự quay tại nhà Việt Nam. Giữ nguyên lỗ chân lông, sợi tóc con bay nhẹ và ánh sáng cửa sổ tự nhiên giúp tăng độ tin cậy lên gấp 3 lần ảnh quảng cáo truyền thống.',
      prompt: `Candid handheld vertical smartphone photograph of ${modelPersona}, showcasing ${beautyStyle}, ${makeupStyle}, warm genuine smile with natural eye catchlights looking directly into the lens. She/He is naturally holding ${name} at chest level with realistic five-finger grip pressure, subtle skin folds on knuckles, and soft contact shadows cast onto the product surface. Visible natural skin texture with fine pores, baby hairs catching soft morning window light, realistic fabric creases on casual everyday clothing. Background is ${setting} with authentic lived-in Vietnamese household details softly out of focus. Captured with ${cameraFeel}, 35mm equivalent focal length, natural daylight color temperature 5200K, subtle organic sensor grain, unedited RAW photography look, ${extraDetail} --ar ${aspectRatio} --style raw --v 6.1`,
      breakdown: {
        face: `${beautyStyle} • ${makeupStyle} • Ánh sáng bắt đồng tử (Eye catchlight)`,
        hands: '5 ngón tay cầm nắm tự nhiên có lực tì & bóng đổ tiếp xúc lên sản phẩm',
        scene: setting,
        optics: `${cameraFeel} • RAW không chỉnh sửa da nhựa`
      }
    },
    {
      id: 'prompt-2',
      title: 'Mẫu 2: Chân dung Nhan sắc & Cận cảnh Chất liệu (Lookbook 85mm)',
      badge: 'Ảnh bìa gian hàng & Banner',
      tool: 'Flux.1 Pro / Midjourney v6.1',
      viExplain:
        'Sử dụng tiêu cự vàng 85mm f/1.4 chuyên trị chân dung giúp khuôn mặt người mẫu cân đối, thon gọn và tôn đường nét đẹp nhất, đồng thời làm nổi bật chi tiết sản phẩm sắc nét.',
      prompt: `Editorial commercial beauty and product portrait of ${modelPersona}, ${beautyStyle}, symmetrical balanced Vietnamese facial features, luminous healthy skin with realistic micro-texture and subtle peach fuzz, ${makeupStyle}, soft butterfly daylight illuminating cheekbones and clear sparkling eyes. Gently presenting ${name} near the collarbone with relaxed elegant hand posture, crisp material texture and authentic product details clearly visible. Shot on medium format camera with 85mm f/1.4 portrait lens, creamy natural bokeh background of ${setting}, soft diffused key light with gentle rim light separating hair strands, true-to-life color grading, ${extraDetail} --ar ${aspectRatio} --style raw --v 6.1`,
      breakdown: {
        face: 'Tiêu cự 85mm chống méo mặt • Ngũ quan cân đối rạng rỡ',
        hands: 'Tư thế đặt tay thanh thoát ngang xương quai xanh, không che khuất sản phẩm',
        scene: `${setting} (Xóa phông mượt f/1.4)`,
        optics: 'Medium Format 85mm • Ánh sáng Butterfly tôn khối mặt'
      }
    },
    {
      id: 'prompt-3',
      title: 'Mẫu 3: Bối cảnh Sử dụng Thực tế trong Đời sống (Lifestyle)',
      badge: 'Ảnh mô tả Shopee & Facebook',
      tool: 'Midjourney v6.1 / Ideogram 2.0',
      viExplain:
        'Đặt người mẫu đang tương tác trực tiếp với sản phẩm trong không gian sinh hoạt thật tại Việt Nam (quán cà phê, căn hộ, góc làm việc), giúp khách hàng dễ hình dung cảnh chính mình đang dùng.',
      prompt: `Authentic lifestyle documentary photograph of ${modelPersona}, ${beautyStyle}, ${makeupStyle}, captured mid-action actively using ${name} in ${setting}. Natural body language, relaxed shoulders, realistic hand anatomy interacting naturally with the item, natural sunlight streaming from the side creating gentle shadows and warm highlights on skin and hair. Rich environmental storytelling with realistic Vietnamese urban apartment/cafe textures in depth of field. Shot on 50mm f/1.8 prime lens, natural dynamic range, candid unposed moment, realistic clothing wrinkles, ${extraDetail} --ar ${aspectRatio} --style raw --v 6.1`,
      breakdown: {
        face: 'Biểu cảm tự nhiên đang trải nghiệm thật, không nhìn chằm chằm cứng nhắc',
        hands: 'Thao tác sử dụng trực tiếp đúng công năng của sản phẩm',
        scene: `Không gian thực tế: ${setting}`,
        optics: 'Ống kính 50mm f/1.8 chuẩn góc nhìn mắt người'
      }
    },
    {
      id: 'prompt-4',
      title: 'Mẫu 4: Lệnh Chuyển động Video 5s–10s (Kling AI / Veo / Runway)',
      badge: 'Dựng video người mẫu nói & cầm sản phẩm',
      tool: 'Kling AI 1.6 / Google Veo / Runway Gen-3',
      viExplain:
        'Dùng ảnh đã tạo ở Mẫu 1 hoặc Mẫu 2 đưa vào công cụ làm video (Image-to-Video) và dán đoạn lệnh này để người mẫu cử động đầu, chớp mắt, mỉm cười và đưa sản phẩm lại gần ống kính mượt mà không bị biến dạng.',
      prompt: `Photorealistic continuous handheld camera motion, ${modelPersona} with ${beautyStyle} gently blinks, smiles warmly, and speaks naturally while raising ${name} slightly closer toward the camera to show product texture. Subtle natural breathing movement, soft breeze gently moving loose hair strands, consistent lighting and stable product geometry without morphing, realistic shallow depth of field in ${setting}, 24fps cinema natural motion, ${extraDetail}`,
      breakdown: {
        face: 'Chớp mắt, mỉm cười & cử động môi tự nhiên theo nhịp nói',
        hands: 'Giữ ổn định hình dạng sản phẩm khi đưa lại gần camera',
        scene: 'Chuyển động máy quay cầm tay nhẹ (Handheld micro-shake)',
        optics: '24fps mượt mà • Chống biến dạng vật thể (Anti-morphing)'
      }
    }
  ];

  return {
    id: `camp_${Date.now()}`,
    createdAt: new Date().toLocaleString('vi-VN'),
    productName: name,
    category,
    price,
    duration,
    tiktokScripts,
    seo: {
      title: seoTitle,
      description: seoDescription,
      keywords: seoKeywords
    },
    livestream: livestreamScript,
    modelPrompts,
    negativePrompt
  };
}

// ============================================================================
// 3. COMPONENT CHÍNH CỦA ỨNG DỤNG DỰNGMẪU (DUNGMAU.VN)
// ============================================================================
export default function App() {
  // Giao diện & điều hướng
  const [darkMode, setDarkMode] = useState(false);
  const [activeTab, setActiveTab] = useState('tiktok');
  const [activeTikTokIdx, setActiveTikTokIdx] = useState(0);
  const [showModelConfig, setShowModelConfig] = useState(true);
  const [showHistoryDrawer, setShowHistoryDrawer] = useState(false);
  const [showPricingModal, setShowPricingModal] = useState(false);
  const [billingCycle, setBillingCycle] = useState('monthly');
  const [selectedUpgradePlan, setSelectedUpgradePlan] = useState('PRO');
  const [sepayLoading, setSepayLoading] = useState(false);
  const [sepayCheckoutData, setSepayCheckoutData] = useState(null);
  const sepayFormRef = useRef(null);
  const [copiedId, setCopiedId] = useState('');
  const [toast, setToast] = useState(null);

  // Hệ thống Tài khoản, Đăng nhập & Tuân thủ Pháp luật VN (Nghị định 13/2023/NĐ-CP)
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem('dungmau_user_v1');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [guestCredits, setGuestCredits] = useState(() => {
    const saved = localStorage.getItem('dungmau_guest_credits');
    return saved !== null ? Number(saved) : 3;
  });
  const [guestPlan, setGuestPlan] = useState('FREE');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState('login'); // 'login' | 'register'
  const [showPrivacyDoc, setShowPrivacyDoc] = useState(false);
  const [showAccountCenter, setShowAccountCenter] = useState(false);

  // Trạng thái Form đăng nhập/đăng ký & Bảo mật chống Brute-force
  const [authForm, setAuthForm] = useState({
    fullName: '',
    identifier: '',
    password: '',
    consentAccepted: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState('');
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState(0);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');

  // Form nhập thông tin sản phẩm & Cấu hình người mẫu
  const [form, setForm] = useState({
    name: SAMPLE_PRODUCTS[0].name,
    category: SAMPLE_PRODUCTS[0].category,
    price: SAMPLE_PRODUCTS[0].price,
    usp: SAMPLE_PRODUCTS[0].usp,
    audience: SAMPLE_PRODUCTS[0].audience,
    tone: SAMPLE_PRODUCTS[0].tone,
    duration: 30,
    modelPersona: SAMPLE_PRODUCTS[0].modelPersona,
    beautyStyle: SAMPLE_PRODUCTS[0].beautyStyle,
    makeupStyle: SAMPLE_PRODUCTS[0].makeupStyle,
    setting: SAMPLE_PRODUCTS[0].setting,
    cameraFeel: SAMPLE_PRODUCTS[0].cameraFeel,
    aspectRatio: '9:16',
    extraDetail: SAMPLE_PRODUCTS[0].extraDetail
  });

  // Trạng thái tạo nội dung & kết quả
  const [isGenerating, setIsGenerating] = useState(false);
  const [campaign, setCampaign] = useState(() => buildCampaignData({
    name: SAMPLE_PRODUCTS[0].name,
    category: SAMPLE_PRODUCTS[0].category,
    price: SAMPLE_PRODUCTS[0].price,
    usp: SAMPLE_PRODUCTS[0].usp,
    audience: SAMPLE_PRODUCTS[0].audience,
    tone: SAMPLE_PRODUCTS[0].tone,
    duration: 30,
    modelPersona: SAMPLE_PRODUCTS[0].modelPersona,
    beautyStyle: SAMPLE_PRODUCTS[0].beautyStyle,
    makeupStyle: SAMPLE_PRODUCTS[0].makeupStyle,
    setting: SAMPLE_PRODUCTS[0].setting,
    cameraFeel: SAMPLE_PRODUCTS[0].cameraFeel,
    aspectRatio: '9:16',
    extraDetail: SAMPLE_PRODUCTS[0].extraDetail
  }));
  const [seoDescText, setSeoDescText] = useState('');
  const [history, setHistory] = useState(() => {
    try {
      const saved = localStorage.getItem('dungmau_history_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Máy nhắc chữ (Teleprompter)
  const [showTeleprompter, setShowTeleprompter] = useState(false);
  const [tpPlaying, setTpPlaying] = useState(false);
  const [tpSceneIdx, setTpSceneIdx] = useState(0);
  const [tpElapsed, setTpElapsed] = useState(0);

  // Tự động nhận kết quả trả về từ Cổng thanh toán SePay (success_url / error_url / cancel_url)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const paymentStatus = params.get('payment');
    const paidPlan = params.get('plan');
    const invoice = params.get('invoice');

    if (paymentStatus) {
      if (paymentStatus === 'success' && paidPlan && PLANS[paidPlan]) {
        handleActivatePlan(paidPlan);
        notify(`Thanh toán SePay thành công (${invoice || paidPlan})! Đã mở khóa gói ${PLANS[paidPlan].name}.`);
      } else if (paymentStatus === 'error') {
        notify('Giao dịch SePay gặp lỗi hoặc bị từ chối. Vui lòng thử lại!', 'error');
      } else if (paymentStatus === 'cancel') {
        notify('Bạn đã hủy phiên thanh toán trên cổng SePay.', 'error');
      }
      // Làm sạch query string trên thanh địa chỉ trình duyệt
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  // Tự động submit form ẩn sang Cổng thanh toán SePay khi nhận đủ checkoutFormfields từ Server
  useEffect(() => {
    if (sepayCheckoutData && sepayFormRef.current) {
      sepayFormRef.current.submit();
    }
  }, [sepayCheckoutData]);

  // Gọi Backend /api/sepay/create-checkout để ký đơn hàng an toàn (giấu secret_key trên server)
  const handleProceedSePayCheckout = async () => {
    if (selectedUpgradePlan === 'FREE') return;
    setSepayLoading(true);
    try {
      const response = await fetch('/api/sepay/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planId: selectedUpgradePlan,
          billingCycle,
          userId: currentUser ? currentUser.uid : 'GUEST'
        })
      });
      const data = await response.json();
      if (!response.ok) {
        if (data.demoFallback) {
          notify('Server chưa gắn SEPAY_SECRET_KEY thật. Bạn có thể bấm nút Kích hoạt test bên cạnh để nghiệm thu!', 'error');
        } else {
          notify(data.error || 'Không thể kết nối cổng thanh toán SePay.', 'error');
        }
        setSepayLoading(false);
        return;
      }
      // Gán checkoutURL + checkoutFormfields -> Form ẩn tự động POST sang SePay
      setSepayCheckoutData(data);
    } catch {
      notify('Đang chạy ở môi trường Local tĩnh (chưa bật API Server). Hãy dùng nút Kích hoạt test bên cạnh!', 'error');
      setSepayLoading(false);
    }
  };

  // Sync Dark Mode
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) root.classList.add('dark');
    else root.classList.remove('dark');
  }, [darkMode]);

  // Sync mô tả SEO mỗi khi đổi chiến dịch
  useEffect(() => {
    if (campaign?.seo?.description) {
      setSeoDescText(campaign.seo.description);
    }
  }, [campaign]);

  // Lưu user & history
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('dungmau_user_v1', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('dungmau_user_v1');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('dungmau_guest_credits', String(guestCredits));
  }, [guestCredits]);

  useEffect(() => {
    try {
      localStorage.setItem('dungmau_history_v1', JSON.stringify(history));
    } catch {
      // Bỏ qua nếu bộ nhớ trình duyệt đầy
    }
  }, [history]);

  // Quyền lợi gói hiện tại
  const activePlanId = currentUser ? currentUser.plan : guestPlan;
  const activePlan = PLANS[activePlanId] || PLANS.FREE;
  const remainingCredits = currentUser ? currentUser.credits : guestCredits;

  const notify = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  };

  const handleCopy = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    notify('Đã sao chép vào bộ nhớ tạm!');
    setTimeout(() => setCopiedId(''), 1800);
  };

  // Quét từ vi phạm chính sách Shopee thời gian thực
  const detectedBannedWords = useMemo(() => {
    const lower = seoDescText.toLowerCase();
    return BANNED_WORDS_MAP.filter((item) => lower.includes(item.word));
  }, [seoDescText]);

  const handleAutoCleanShopee = () => {
    if (!activePlan.allowShopeeAutoClean) {
      setSelectedUpgradePlan('STARTER');
      setShowPricingModal(true);
      return;
    }
    let cleaned = seoDescText;
    BANNED_WORDS_MAP.forEach(({ word, replace }) => {
      const regex = new RegExp(word, 'gi');
      cleaned = cleaned.replace(regex, replace);
    });
    setSeoDescText(cleaned);
    notify('Đã thay thế toàn bộ từ vi phạm bằng cụm từ an toàn chuẩn sàn!');
  };

  // Logic chạy Máy nhắc chữ theo từng giây
  const currentScriptScenes = campaign?.tiktokScripts?.[activeTikTokIdx]?.scenes || [];
  useEffect(() => {
    if (!showTeleprompter || !tpPlaying || currentScriptScenes.length === 0) return;
    const timer = setInterval(() => {
      setTpElapsed((prev) => {
        const currentScene = currentScriptScenes[tpSceneIdx];
        if (!currentScene) return 0;
        if (prev + 1 >= currentScene.sec) {
          // Giới hạn 2 cảnh đầu nếu ở gói FREE
          if (!activePlan.allowFullTeleprompter && tpSceneIdx >= 1) {
            setTpPlaying(false);
            return prev;
          }
          if (tpSceneIdx + 1 < currentScriptScenes.length) {
            setTpSceneIdx((idx) => idx + 1);
            return 0;
          } else {
            setTpPlaying(false);
            return currentScene.sec;
          }
        }
        return prev + 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [showTeleprompter, tpPlaying, tpSceneIdx, currentScriptScenes, activePlan.allowFullTeleprompter]);

  // Xử lý tạo toàn bộ chiến dịch
  const handleGenerate = () => {
    if (!form.name.trim()) {
      notify('Vui lòng nhập tên sản phẩm trước khi tạo!', 'error');
      return;
    }
    if (form.duration > activePlan.maxDuration) {
      setSelectedUpgradePlan(form.duration === 45 ? 'STARTER' : 'PRO');
      setShowPricingModal(true);
      return;
    }
    if (activePlanId !== 'PRO' && activePlanId !== 'AGENCY' && remainingCredits <= 0) {
      setSelectedUpgradePlan('STARTER');
      setShowPricingModal(true);
      notify('Bạn đã dùng hết lượt miễn phí. Nâng cấp gói để tiếp tục nhé!', 'error');
      return;
    }

    setIsGenerating(true);
    setTimeout(() => {
      const newCamp = buildCampaignData(form);
      setCampaign(newCamp);
      setActiveTikTokIdx(0);
      setHistory((prev) => [newCamp, ...prev].slice(0, activePlan.maxHistory));

      if (activePlanId !== 'PRO' && activePlanId !== 'AGENCY') {
        if (currentUser) {
          setCurrentUser((u) => ({
            ...u,
            credits: Math.max(0, u.credits - 1),
            auditLogs: [
              { time: new Date().toLocaleString('vi-VN'), action: `Tạo bộ kịch bản: ${form.name}`, ip: '14.232.xx.xx' },
              ...(u.auditLogs || [])
            ].slice(0, 20)
          }));
        } else {
          setGuestCredits((c) => Math.max(0, c - 1));
        }
      }
      setIsGenerating(false);
      notify('Đã dựng xong bộ kịch bản từng giây & 4 câu lệnh người mẫu!');
    }, 550);
  };

  // Tạo lại riêng bộ 4 câu lệnh người mẫu
  const handleRegeneratePromptsOnly = () => {
    if (activePlanId !== 'PRO' && activePlanId !== 'AGENCY' && remainingCredits <= 0) {
      setSelectedUpgradePlan('STARTER');
      setShowPricingModal(true);
      return;
    }
    const updated = buildCampaignData(form);
    setCampaign((prev) => ({
      ...prev,
      modelPrompts: updated.modelPrompts,
      negativePrompt: updated.negativePrompt
    }));
    if (activePlanId !== 'PRO' && activePlanId !== 'AGENCY') {
      if (currentUser) setCurrentUser((u) => ({ ...u, credits: Math.max(0, u.credits - 1) }));
      else setGuestCredits((c) => Math.max(0, c - 1));
    }
    notify('Đã làm mới 4 câu lệnh dựng ảnh người mẫu theo thông số mới!');
  };

  // Xuất file .TXT
  const handleDownloadTxt = (mode = 'single') => {
    if (mode === 'single' && !activePlan.allowTxtExport) {
      setSelectedUpgradePlan('PRO');
      setShowPricingModal(true);
      return;
    }
    if (mode === 'all' && !activePlan.allowAllInOneExport) {
      setSelectedUpgradePlan('AGENCY');
      setShowPricingModal(true);
      return;
    }

    let content = `====================================================\n`;
    content += `DỰNGMẪU (${BRAND.domain}) — HỒ SƠ CHIẾN DỊCH BÁN HÀNG\n`;
    content += `Sản phẩm: ${campaign.productName}\n`;
    content += `Thời lượng: ${campaign.duration} giây | Ngày tạo: ${campaign.createdAt}\n`;
    content += `====================================================\n\n`;

    content += `[1] KỊCH BẢN VIDEO TIKTOK / REELS CHI TIẾT TỪNG GIÂY\n`;
    campaign.tiktokScripts.forEach((sc, idx) => {
      content += `\n--- ${sc.title} (${sc.hookRate}) ---\n`;
      sc.scenes.forEach((s) => {
        content += `[${s.time}] (${s.sec}s) | Góc máy: ${s.camera}\n`;
        content += `   - Hành động: ${s.action}\n`;
        content += `   - Lời thoại: "${s.voice}"\n`;
        content += `   - Chữ màn hình: ${s.overlay} | Âm thanh: ${s.sfx}\n`;
      });
    });

    if (mode === 'all') {
      content += `\n\n[2] MÔ TẢ CHUẨN SEO SHOPEE\n`;
      content += `Tiêu đề: ${campaign.seo.title}\n\n${seoDescText}\n`;

      content += `\n\n[3] KỊCH BẢN LIVESTREAM 4 CHẶNG\n`;
      campaign.livestream.stages.forEach((st) => {
        content += `* ${st.time} - ${st.title}: ${st.script}\n`;
      });

      content += `\n\n[4] BỘ CÂU LỆNH DỰNG ẢNH & VIDEO NGƯỜI MẪU SIÊU THỰC\n`;
      campaign.modelPrompts.forEach((mp) => {
        content += `\n* ${mp.title} (${mp.tool}):\n${mp.prompt}\n`;
      });
      content += `\n* Negative Prompt (Chặn lỗi):\n${campaign.negativePrompt}\n`;
    }

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `DungMau_${mode === 'all' ? 'TronBo' : 'KichBan'}_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    notify(mode === 'all' ? 'Đã xuất trọn bộ chiến dịch 4 kênh!' : 'Đã tải xuống tệp kịch bản .TXT!');
  };

  // ============================================================================
  // 4. XỬ LÝ ĐĂNG NHẬP, ĐĂNG KÝ & BẢO MẬT PHÁP LUẬT VIỆT NAM (NĐ 13/2023/NĐ-CP)
  // ============================================================================
  const passwordStrength = useMemo(() => {
    const p = authForm.password;
    let score = 0;
    if (p.length >= 8) score++;
    if (/[A-Z]/.test(p) && /[a-z]/.test(p)) score++;
    if (/[0-9]/.test(p)) score++;
    if (/[^A-Za-z0-9]/.test(p)) score++;
    return score;
  }, [authForm.password]);

  const handleAuthSubmit = (e) => {
    e.preventDefault();
    setAuthError('');

    if (Date.now() < lockoutUntil) {
      const secLeft = Math.ceil((lockoutUntil - Date.now()) / 1000);
      setAuthError(`Tài khoản tạm khóa bảo vệ trong ${secLeft}s do nhập sai nhiều lần.`);
      return;
    }

    const idTrim = authForm.identifier.trim();
    const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(idTrim);
    const isVnPhone = /^(0|\+84)(3|5|7|8|9)[0-9]{8}$/.test(idTrim.replace(/\s+/g, ''));

    if (!isEmail && !isVnPhone) {
      setAuthError('Vui lòng nhập đúng định dạng Email hoặc Số điện thoại Việt Nam (VD: 0912345678).');
      return;
    }

    if (authForm.password.length < 8) {
      const nextFails = failedAttempts + 1;
      setFailedAttempts(nextFails);
      if (nextFails >= 5) {
        setLockoutUntil(Date.now() + 30000);
        setAuthError('Nhập sai 5 lần liên tiếp. Hệ thống tạm khóa 30 giây để bảo vệ tài khoản.');
      } else {
        setAuthError(`Mật khẩu phải từ 8 ký tự trở lên (Còn ${5 - nextFails} lần thử).`);
      }
      return;
    }

    if (authMode === 'register') {
      if (!authForm.fullName.trim()) {
        setAuthError('Vui lòng nhập họ tên hoặc tên cửa hàng.');
        return;
      }
      if (!authForm.consentAccepted) {
        setAuthError('Bạn cần tích chọn đồng ý Chính sách Bảo vệ Dữ liệu Cá nhân (Nghị định 13/2023/NĐ-CP) để tiếp tục.');
        return;
      }
    }

    const nowStr = new Date().toLocaleString('vi-VN');
    const newUser = {
      uid: `vn_usr_${Date.now()}`,
      fullName: authMode === 'register' ? authForm.fullName.trim() : idTrim.split('@')[0],
      identifier: idTrim,
      plan: 'FREE',
      credits: 5,
      twoFactorEnabled: false,
      consentVersion: 'v1.0-ND13-2023',
      consentedAt: nowStr,
      dataRegion: 'Việt Nam (VN-DC-01)',
      sessions: [
        { id: 'sess_1', device: 'Trình duyệt hiện tại (Windows / Chrome)', location: 'Hà Nội, Việt Nam', active: true, time: 'Đang hoạt động' }
      ],
      auditLogs: [
        { time: nowStr, action: authMode === 'register' ? 'Khởi tạo tài khoản & Xác nhận đồng ý NĐ 13/2023' : 'Đăng nhập thành công (Phiên mã hóa TLS 1.3)', ip: '14.232.xx.xx' }
      ]
    };

    setCurrentUser(newUser);
    setFailedAttempts(0);
    setShowAuthModal(false);
    setAuthForm({ fullName: '', identifier: '', password: '', consentAccepted: false });
    notify(`Chào mừng ${newUser.fullName} đến với ${BRAND.name}!`);
  };

  const handleQuickDemoProLogin = () => {
    const nowStr = new Date().toLocaleString('vi-VN');
    const demoUser = {
      uid: 'vn_demo_pro_01',
      fullName: 'Minh Anh Store (Demo Pro)',
      identifier: 'minhanh.shop@dungmau.vn',
      plan: 'PRO',
      credits: 9999,
      twoFactorEnabled: true,
      consentVersion: 'v1.0-ND13-2023',
      consentedAt: nowStr,
      dataRegion: 'Việt Nam (VN-DC-01)',
      sessions: [
        { id: 'sess_1', device: 'Windows 11 • Chrome Desktop', location: 'Hà Nội, Việt Nam', active: true, time: 'Đang hoạt động' },
        { id: 'sess_2', device: 'iPhone 15 Pro • Safari Mobile', location: 'TP. Hồ Chí Minh, Việt Nam', active: false, time: '2 giờ trước' }
      ],
      auditLogs: [
        { time: nowStr, action: 'Đăng nhập nhanh tài khoản Demo Đạo Diễn Pro', ip: '113.190.xx.xx' },
        { time: nowStr, action: 'Xác nhận đồng ý xử lý dữ liệu theo Nghị định 13/2023/NĐ-CP', ip: '113.190.xx.xx' }
      ]
    };
    setCurrentUser(demoUser);
    setShowAuthModal(false);
    notify('Đã đăng nhập tài khoản Demo Pro Director!');
  };

  // Quyền xuất dữ liệu cá nhân (Điều 14 - Nghị định 13/2023/NĐ-CP)
  const handleExportPersonalData = () => {
    if (!currentUser) return;
    const exportPayload = {
      legalBasis: 'Nghị định 13/2023/NĐ-CP về Bảo vệ dữ liệu cá nhân (Việt Nam)',
      exportedAt: new Date().toISOString(),
      profile: currentUser,
      savedCampaignsCount: history.length,
      campaigns: history
    };
    const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `DuLieuCaNhan_DungMau_${currentUser.uid}.json`;
    a.click();
    URL.revokeObjectURL(url);
    notify('Đã xuất toàn bộ dữ liệu cá nhân định dạng JSON theo NĐ 13/2023!');
  };

  // Quyền xóa vĩnh viễn dữ liệu ("Quyền được lãng quên" - Điều 16 NĐ 13/2023/NĐ-CP)
  const handlePermanentDeleteAccount = () => {
    if (deleteConfirmText.trim().toUpperCase() !== 'XOA TAI KHOAN') {
      notify('Vui lòng nhập chính xác cụm từ XOA TAI KHOAN để xác nhận!', 'error');
      return;
    }
    localStorage.removeItem('dungmau_user_v1');
    localStorage.removeItem('dungmau_history_v1');
    setCurrentUser(null);
    setHistory([]);
    setDeleteConfirmText('');
    setShowAccountCenter(false);
    notify('Đã xóa vĩnh viễn tài khoản và toàn bộ dữ liệu khỏi hệ thống!');
  };

  // Kích hoạt gói sau thanh toán VietQR (Test)
  const handleActivatePlan = (planKey) => {
    const planObj = PLANS[planKey];
    if (currentUser) {
      setCurrentUser((u) => ({
        ...u,
        plan: planKey,
        credits: planKey === 'STARTER' ? u.credits + 25 : 9999,
        auditLogs: [
          { time: new Date().toLocaleString('vi-VN'), action: `Kích hoạt gói ${planObj.name} (${planObj.badge})`, ip: '14.232.xx.xx' },
          ...(u.auditLogs || [])
        ]
      }));
    } else {
      setGuestPlan(planKey);
      if (planKey === 'STARTER') setGuestCredits((c) => c + 25);
    }
    setShowPricingModal(false);
    notify(`Kích hoạt thành công gói ${planObj.name}!`);
  };

  const switchPlanQuickTest = (planKey) => {
    if (currentUser) {
      setCurrentUser((u) => ({
        ...u,
        plan: planKey,
        credits: planKey === 'FREE' ? 3 : planKey === 'STARTER' ? 25 : 9999
      }));
    } else {
      setGuestPlan(planKey);
      setGuestCredits(planKey === 'FREE' ? 3 : planKey === 'STARTER' ? 25 : 9999);
    }
    notify(`Đã chuyển sang chế độ kiểm thử gói ${PLANS[planKey].badge}`);
  };

  return (
    <div className={`min-h-screen transition-colors duration-200 ${darkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {/* Toast thông báo */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl border text-sm font-medium bg-slate-900 text-white border-slate-700 animate-bounce">
          {toast.type === 'error' ? <AlertTriangle className="w-4 h-4 text-amber-400" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          <span>{toast.msg}</span>
        </div>
      )}

      {/* ==================================================================== */}
      {/* HEADER ĐIỀU HƯỚNG & QUẢN LÝ TÀI KHOẢN                                */}
      {/* ==================================================================== */}
      <header className="sticky top-0 z-30 border-b backdrop-blur-md bg-white/90 dark:bg-slate-900/90 border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          {/* Logo Thương hiệu DựngMẫu */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <Clapperboard className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight">{BRAND.name}</span>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  {BRAND.domain}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">{BRAND.tagline}</p>
            </div>
          </div>

          {/* Cụm công cụ phải */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Bộ chuyển nhanh 4 gói để chủ dự án nghiệm thu */}
            <div className="hidden xl:flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs">
              <span className="px-2 text-slate-400 font-medium">Test gói:</span>
              {Object.keys(PLANS).map((key) => (
                <button
                  key={key}
                  onClick={() => switchPlanQuickTest(key)}
                  className={`px-2 py-1 rounded-md font-semibold transition ${
                    activePlanId === key
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-700'
                  }`}
                >
                  {key}
                </button>
              ))}
            </div>

            {/* Số lượt & Hạng gói */}
            <button
              onClick={() => setShowPricingModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border border-amber-300/80 bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800 hover:bg-amber-100 transition"
            >
              <Crown className="w-3.5 h-3.5 text-amber-500" />
              <span>{activePlan.badge}</span>
              <span className="opacity-60">•</span>
              <span>{activePlanId === 'PRO' || activePlanId === 'AGENCY' ? 'Không giới hạn' : `${remainingCredits} lượt`}</span>
            </button>

            {/* Lịch sử */}
            <button
              onClick={() => setShowHistoryDrawer(true)}
              title="Lịch sử kịch bản đã lưu"
              className="relative p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              <History className="w-4 h-4" />
              {history.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center font-bold">
                  {history.length}
                </span>
              )}
            </button>

            {/* Dark/Light Mode */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              title="Đổi giao diện Sáng / Tối"
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Tài khoản / Đăng nhập */}
            {currentUser ? (
              <button
                onClick={() => setShowAccountCenter(true)}
                className="flex items-center gap-2 pl-2.5 pr-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-semibold hover:bg-emerald-100 transition"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span className="max-w-[110px] truncate">{currentUser.fullName}</span>
              </button>
            ) : (
              <button
                onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold hover:opacity-90 transition shadow-sm"
              >
                <User className="w-3.5 h-3.5" />
                <span>Đăng nhập</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Banner nhắc tuân thủ dữ liệu & Test nhanh tài khoản */}
      {!currentUser && (
        <div className="bg-indigo-600 text-white text-xs py-2 px-4">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0 text-indigo-200" />
              <span>
                Bạn đang dùng chế độ Khách ({guestCredits} lượt miễn phí). Đăng ký tài khoản để đồng bộ lịch sử & bảo vệ dữ liệu theo <strong>Nghị định 13/2023/NĐ-CP</strong>.
              </span>
            </div>
            <button
              onClick={handleQuickDemoProLogin}
              className="px-2.5 py-1 rounded-lg bg-white text-indigo-700 font-bold hover:bg-indigo-50 transition shrink-0"
            >
              Vào nhanh Demo Pro
            </button>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* NỘI DUNG CHÍNH: CỘT NHẬP LIỆU (TRÁI) & STUDIO KẾT QUẢ (PHẢI)        */}
      {/* ==================================================================== */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* CỘT TRÁI: THÔNG TIN SẢN PHẨM & CẤU HÌNH NGƯỜI MẪU */}
        <section className="lg:col-span-4 space-y-5">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-base flex items-center gap-2">
                <Package className="w-4 h-4 text-indigo-600" />
                <span>1. Thông tin sản phẩm</span>
              </h2>
              <span className="text-[11px] text-slate-400">Test 1 chạm:</span>
            </div>

            {/* 3 Nút điền mẫu nhanh */}
            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_PRODUCTS.map((sp, i) => (
                <button
                  key={i}
                  onClick={() => setForm({ ...form, ...sp })}
                  className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950 hover:text-indigo-600 font-medium transition border border-transparent hover:border-indigo-200"
                >
                  {sp.label}
                </button>
              ))}
            </div>

            {/* Tên sản phẩm */}
            <div>
              <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Tên sản phẩm *</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="VD: Nồi chiên không dầu mặt kính 6L..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Ngành hàng & Giá bán */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Ngành hàng</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs font-medium"
                >
                  <option>Thời trang & Phụ kiện</option>
                  <option>Chăm sóc cá nhân & Làm đẹp</option>
                  <option>Gia dụng & Nhà bếp</option>
                  <option>Điện tử & Phụ kiện số</option>
                  <option>Mẹ & Bé</option>
                  <option>Thực phẩm & Đồ uống</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Giá & Ưu đãi</label>
                <input
                  type="text"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                  placeholder="VD: 199.000đ (Freeship)"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs"
                />
              </div>
            </div>

            {/* Điểm mạnh sản phẩm */}
            <div>
              <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Điểm ăn tiền nhất (cách nhau bằng dấu phẩy)</label>
              <textarea
                rows={2}
                value={form.usp}
                onChange={(e) => setForm({ ...form, usp: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Khách hàng mục tiêu */}
            <div>
              <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Khách hàng mục tiêu</label>
              <input
                type="text"
                value={form.audience}
                onChange={(e) => setForm({ ...form, audience: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs"
              />
            </div>

            {/* Chọn thời lượng kịch bản khớp từng giây */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">Thời lượng video (khớp từng giây)</label>
                <span className="text-[11px] text-indigo-600 font-semibold">{form.duration} giây</span>
              </div>
              <div className="grid grid-cols-5 gap-1.5">
                {[15, 30, 45, 60, 90].map((sec) => {
                  const locked = sec > activePlan.maxDuration;
                  return (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => {
                        if (locked) {
                          setSelectedUpgradePlan(sec === 45 ? 'STARTER' : 'PRO');
                          setShowPricingModal(true);
                        } else {
                          setForm({ ...form, duration: sec });
                        }
                      }}
                      className={`py-2 rounded-xl text-xs font-bold border flex flex-col items-center justify-center transition ${
                        form.duration === sec
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                          : locked
                          ? 'bg-slate-100/80 dark:bg-slate-800/40 text-slate-400 border-slate-200 dark:border-slate-800'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-indigo-400'
                      }`}
                    >
                      <span>{sec}s</span>
                      {locked && <span className="text-[9px] text-amber-500 font-extrabold">{sec === 45 ? 'STARTER' : 'PRO'}</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* KHỐI 2: CẤU HÌNH DỰNG NGƯỜI MẪU NHƯ THẬT */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-3.5">
            <button
              type="button"
              onClick={() => setShowModelConfig(!showModelConfig)}
              className="w-full flex items-center justify-between text-left"
            >
              <span className="font-bold text-sm flex items-center gap-2">
                <Camera className="w-4 h-4 text-rose-500" />
                <span>2. Cấu hình Người mẫu & Bối cảnh thật</span>
              </span>
              {showModelConfig ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>

            {showModelConfig && (
              <div className="space-y-3 pt-1">
                <div>
                  <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Chân dung người mẫu Việt Nam</label>
                  <select
                    value={form.modelPersona}
                    onChange={(e) => setForm({ ...form, modelPersona: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs"
                  >
                    <option>Nữ Việt Nam 22 tuổi, dáng thanh mảnh, phong cách năng động</option>
                    <option>Nữ Việt Nam 27 tuổi, gương mặt phúc hậu, tóc buộc nửa đầu tự nhiên</option>
                    <option>Phụ nữ Việt Nam 33 tuổi, thần thái sang trọng, tự tin</option>
                    <option>Nam Việt Nam 26 tuổi, nụ cười rạng rỡ, hàm răng trắng đều tự nhiên</option>
                    <option>Mẹ trẻ Việt Nam 29 tuổi bế/chơi cùng bé trong phòng khách</option>
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Đường nét khuôn mặt</label>
                    <select
                      value={form.beautyStyle}
                      onChange={(e) => setForm({ ...form, beautyStyle: e.target.value })}
                      className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs"
                    >
                      <option>Nàng thơ trong trẻo, ngũ quan hài hòa</option>
                      <option>Hotgirl hiện đại, đường nét sắc sảo cuốn hút</option>
                      <option>Tiểu thư thanh lịch, da trắng hồng rạng rỡ</option>
                      <option>Nam thần điển trai, góc hàm sắc nét, thân thiện</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Trang điểm & Làn da</label>
                    <select
                      value={form.makeupStyle}
                      onChange={(e) => setForm({ ...form, makeupStyle: e.target.value })}
                      className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs"
                    >
                      <option>Trang điểm trong suốt tự nhiên (No-makeup)</option>
                      <option>Trang điểm nhẹ kiểu Hàn Quốc căng bóng</option>
                      <option>Mặt mộc khỏe khoắn, làn da nam tính tự nhiên</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Bối cảnh đời thực Việt Nam</label>
                  <input
                    type="text"
                    value={form.setting}
                    onChange={(e) => setForm({ ...form, setting: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Chất ảnh & Ống kính</label>
                    <select
                      value={form.cameraFeel}
                      onChange={(e) => setForm({ ...form, cameraFeel: e.target.value })}
                      className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs"
                    >
                      <option>iPhone 15 Pro quay cầm tay chân thực (UGC)</option>
                      <option>Sony A7R V ống kính 85mm f/1.4 xóa phông mượt</option>
                      <option>Máy quay Cinema 35mm ánh sáng tự nhiên</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Khung hình</label>
                    <select
                      value={form.aspectRatio}
                      onChange={(e) => setForm({ ...form, aspectRatio: e.target.value })}
                      className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs font-bold"
                    >
                      <option value="9:16">9:16 (Dọc)</option>
                      <option value="1:1">1:1 (Vuông)</option>
                      <option value="16:9">16:9 (Ngang)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">Chi tiết tay cầm & đạo cụ thêm</label>
                  <input
                    type="text"
                    value={form.extraDetail}
                    onChange={(e) => setForm({ ...form, extraDetail: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Nút hành động chính */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-purple-600 hover:opacity-95 text-white font-bold text-sm shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 transition disabled:opacity-60"
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>{isGenerating ? 'Đang dựng kịch bản & câu lệnh...' : 'Dựng Kịch Bản & Mẫu Ngay'}</span>
          </button>
        </section>

        {/* ================================================================== */}
        {/* CỘT PHẢI: 5 TAB LÀM VIỆC CHUYÊN SÂU                                */}
        {/* ================================================================== */}
        <section className="lg:col-span-8 space-y-4">
          {/* Thanh điều hướng 5 Tab */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex flex-wrap gap-1">
              {[
                { id: 'tiktok', label: 'TikTok Từng Giây', icon: Clapperboard },
                { id: 'shopee', label: 'SEO Shopee', icon: ShoppingBag },
                { id: 'live', label: 'Livestream 4 Chặng', icon: Radio },
                { id: 'model', label: 'Dựng Người Mẫu Thật', icon: Camera, badge: 'Mở 100%' },
                { id: 'guide', label: 'Cẩm Nang A–Z', icon: BookOpen }
              ].map((t) => {
                const Icon = t.icon;
                const isActive = activeTab === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => setActiveTab(t.id)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{t.label}</span>
                    {t.badge && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isActive ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'}`}>
                        {t.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Nút Xuất Trọn Bộ (Gói Agency) */}
            <button
              onClick={() => handleDownloadTxt('all')}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border border-violet-200 dark:border-violet-800 bg-violet-50 dark:bg-violet-950/50 text-violet-700 dark:text-violet-300 hover:bg-violet-100 transition"
            >
              {!activePlan.allowAllInOneExport && <Lock className="w-3 h-3 text-amber-500" />}
              <Download className="w-3.5 h-3.5" />
              <span>Xuất Trọn Bộ</span>
            </button>
          </div>

          {/* ---------------------------------------------------------------- */}
          {/* TAB 1: KỊCH BẢN TIKTOK / REELS KHỚP CHI TIẾT TỪNG GIÂY           */}
          {/* ---------------------------------------------------------------- */}
          {activeTab === 'tiktok' && (
            <div className="space-y-4">
              {/* Chọn 3 góc tiếp cận + Nút Máy nhắc chữ + Xuất file */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1.5">
                  {campaign.tiktokScripts.map((sc, idx) => {
                    const lockedAngle = idx > 0 && !activePlan.allowAllTikTokAngles;
                    return (
                      <button
                        key={sc.id}
                        onClick={() => setActiveTikTokIdx(idx)}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition ${
                          activeTikTokIdx === idx
                            ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-slate-900'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-400'
                        }`}
                      >
                        {lockedAngle && <Lock className="w-3 h-3 text-amber-500" />}
                        <span>Góc {idx + 1}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setTpSceneIdx(0);
                      setTpElapsed(0);
                      setTpPlaying(true);
                      setShowTeleprompter(true);
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Máy nhắc chữ</span>
                  </button>

                  <button
                    onClick={() => handleDownloadTxt('single')}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold hover:bg-slate-50 transition"
                  >
                    {!activePlan.allowTxtExport && <Lock className="w-3 h-3 text-amber-500" />}
                    <Download className="w-3.5 h-3.5" />
                    <span>Tải .TXT</span>
                  </button>
                </div>
              </div>

              {/* Nội dung Kịch bản đang chọn */}
              {(() => {
                const currentSc = campaign.tiktokScripts[activeTikTokIdx];
                const isLocked = activeTikTokIdx > 0 && !activePlan.allowAllTikTokAngles;

                return (
                  <div className="relative rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
                      <div>
                        <h3 className="font-bold text-base">{currentSc.title}</h3>
                        <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                          <span className="px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 font-semibold">
                            {currentSc.badge}
                          </span>
                          <span>• {currentSc.hookRate}</span>
                          <span>• Tổng {campaign.duration} giây</span>
                        </div>
                      </div>
                      {!isLocked && (
                        <button
                          onClick={() => {
                            const txt = currentSc.scenes.map((s) => `[${s.time}] (${s.camera})\nLời thoại: "${s.voice}"\nHành động: ${s.action}`).join('\n\n');
                            handleCopy(txt, currentSc.id);
                          }}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold hover:bg-indigo-50 hover:text-indigo-600 transition"
                        >
                          {copiedId === currentSc.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>Sao chép kịch bản</span>
                        </button>
                      )}
                    </div>

                    {/* Khóa Paywall cho Góc 2 & 3 nếu ở gói FREE */}
                    {isLocked ? (
                      <div className="py-12 px-4 text-center space-y-3">
                        <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-600 flex items-center justify-center mx-auto">
                          <Lock className="w-6 h-6" />
                        </div>
                        <h4 className="font-bold text-base">Mở khóa trọn bộ 3 góc kịch bản chuyển đổi cao</h4>
                        <p className="text-xs text-slate-500 max-w-md mx-auto">
                          Gói Trải Nghiệm hiển thị mẫu Góc 1. Nâng cấp từ gói <strong>Starter (79.000đ)</strong> để mở toàn bộ Góc So Sánh, Góc Đập Hộp UGC và thời lượng 45s–90s.
                        </p>
                        <button
                          onClick={() => { setSelectedUpgradePlan('STARTER'); setShowPricingModal(true); }}
                          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md transition"
                        >
                          Mở khóa ngay chỉ từ 79.000đ
                        </button>
                      </div>
                    ) : (
                      <div className="divide-y divide-slate-100 dark:divide-slate-800 mt-2">
                        {currentSc.scenes.map((scene, sIdx) => (
                          <div key={sIdx} className="py-4 grid grid-cols-1 md:grid-cols-12 gap-3">
                            <div className="md:col-span-3 space-y-1">
                              <span className="inline-block px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-mono text-xs font-bold">
                                {scene.time}
                              </span>
                              <p className="text-[11px] font-semibold text-slate-500">{scene.camera}</p>
                            </div>
                            <div className="md:col-span-9 space-y-2">
                              <p className="text-sm font-bold text-slate-900 dark:text-white leading-relaxed">
                                “{scene.voice}”
                              </p>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                                <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/70">
                                  <span className="font-semibold text-slate-500">Hành động: </span>
                                  <span>{scene.action}</span>
                                </div>
                                <div className="p-2 rounded-lg bg-amber-50/70 dark:bg-amber-950/30">
                                  <span className="font-semibold text-amber-700 dark:text-amber-300">Chữ màn hình: </span>
                                  <span className="font-bold">{scene.overlay}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}

          {/* ---------------------------------------------------------------- */}
          {/* TAB 2: SEO SHOPEE & BỘ LỌC TỪ VI PHẠM CHÍNH SÁCH SÀN             */}
          {/* ---------------------------------------------------------------- */}
          {activeTab === 'shopee' && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="font-bold text-base">Tiêu đề & Mô tả chuẩn tìm kiếm Shopee</h3>
                  <p className="text-xs text-slate-500">Tự động quét và cảnh báo từ ngữ dễ bị sàn khóa sản phẩm hoặc bóp hiển thị.</p>
                </div>
                <button
                  onClick={() => handleCopy(`${campaign.seo.title}\n\n${seoDescText}`, 'seo-full')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition"
                >
                  {copiedId === 'seo-full' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Sao chép toàn bộ</span>
                </button>
              </div>

              {/* Tiêu đề chuẩn 120 ký tự */}
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-bold text-slate-600 dark:text-slate-300">Tiêu đề sản phẩm gợi ý</span>
                  <span className={`font-mono font-bold ${campaign.seo.title.length <= 120 ? 'text-emerald-600' : 'text-rose-500'}`}>
                    {campaign.seo.title.length}/120 ký tự
                  </span>
                </div>
                <p className="text-sm font-bold">{campaign.seo.title}</p>
              </div>

              {/* Cảnh báo từ vi phạm */}
              {detectedBannedWords.length > 0 ? (
                <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-rose-700 dark:text-rose-300">
                      <AlertTriangle className="w-4 h-4" />
                      <span>Phát hiện {detectedBannedWords.length} cụm từ vi phạm chính sách sàn:</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {detectedBannedWords.map((b, i) => (
                        <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-rose-100 dark:bg-rose-900 text-rose-800 dark:text-rose-200 font-semibold">
                          “{b.word}” → nên đổi thành “{b.replace}”
                        </span>
                      ))}
                    </div>
                  </div>
                  <button
                    onClick={handleAutoCleanShopee}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-sm transition shrink-0"
                  >
                    {!activePlan.allowShopeeAutoClean && <Lock className="w-3 h-3" />}
                    <span>Làm sạch 1 chạm</span>
                  </button>
                </div>
              ) : (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Mô tả đã sạch từ cấm chính sách sàn Shopee & TikTok Shop!</span>
                </div>
              )}

              {/* Ô chỉnh sửa mô tả */}
              <div>
                <label className="block text-xs font-semibold mb-1 text-slate-500">Nội dung mô tả (Bạn có thể gõ thử từ "rẻ nhất" hoặc "zalo" để kiểm tra bộ lọc):</label>
                <textarea
                  rows={12}
                  value={seoDescText}
                  onChange={(e) => setSeoDescText(e.target.value)}
                  className="w-full p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 text-xs leading-relaxed font-sans focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Bộ từ khóa gợi ý */}
              <div>
                <span className="block text-xs font-bold mb-1.5 text-slate-600 dark:text-slate-300">Từ khóa gợi ý đặt quảng cáo đấu thầu Shopee:</span>
                <div className="flex flex-wrap gap-1.5">
                  {campaign.seo.keywords.map((kw, i) => (
                    <span key={i} className="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-xs font-medium">
                      #{kw}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ---------------------------------------------------------------- */}
          {/* TAB 3: KỊCH BẢN LIVESTREAM 4 CHẶNG & XỬ LÝ TỪ CHỐI               */}
          {/* ---------------------------------------------------------------- */}
          {activeTab === 'live' && (
            <div className="space-y-4">
              <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-3">
                <h3 className="font-bold text-base">Lộ trình phiên Live 10 phút chốt đơn cuốn chiếu</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {campaign.livestream.stages.map((st, idx) => (
                    <div key={idx} className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/50 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300">
                          {st.time}
                        </span>
                        <button
                          onClick={() => handleCopy(st.script, `live-${idx}`)}
                          className="text-xs text-slate-400 hover:text-indigo-600"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <h4 className="font-bold text-xs">{st.title}</h4>
                      <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{st.script}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-base">Bộ câu trả lời mẫu khi khách chê đắt / phân vân</h3>
                  {!activePlan.allowFullLiveObjections && (
                    <button
                      onClick={() => { setSelectedUpgradePlan('STARTER'); setShowPricingModal(true); }}
                      className="text-xs font-bold text-indigo-600 hover:underline flex items-center gap-1"
                    >
                      <Lock className="w-3 h-3" /> Mở đủ 4 tình huống
                    </button>
                  )}
                </div>

                <div className="space-y-2.5">
                  {campaign.livestream.objections.map((obj, idx) => {
                    const lockedObj = idx >= 2 && !activePlan.allowFullLiveObjections;
                    return (
                      <div key={idx} className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
                        <p className="text-xs font-bold text-amber-700 dark:text-amber-400">{obj.question}</p>
                        {lockedObj ? (
                          <div className="flex items-center justify-between pt-1">
                            <span className="text-xs text-slate-400 blur-[3px] select-none">
                              Câu trả lời mẫu chuyên sâu giúp giữ chân khách hàng và chốt đơn ngay trên sóng...
                            </span>
                            <button
                              onClick={() => { setSelectedUpgradePlan('STARTER'); setShowPricingModal(true); }}
                              className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-800 text-[11px] font-bold shrink-0"
                            >
                              Mở khóa Starter
                            </button>
                          </div>
                        ) : (
                          <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">{obj.answer}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ---------------------------------------------------------------- */}
          {/* TAB 4: DỰNG NGƯỜI MẪU THẬT (MỞ KHÓA 100% THEO LƯỢT)               */}
          {/* ---------------------------------------------------------------- */}
          {activeTab === 'model' && (
            <div className="space-y-4">
              <div className="rounded-2xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/30 p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
                      Mở khóa toàn bộ 4 bộ câu lệnh dựng mẫu siêu thực
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    Đặc tả chi tiết lỗ chân lông, ánh sáng bắt đồng tử, cấu trúc 5 ngón tay cầm sản phẩm và bối cảnh đời thực Việt Nam.
                  </p>
                </div>
                <button
                  onClick={handleRegeneratePromptsOnly}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Tạo lại bộ câu lệnh mới</span>
                </button>
              </div>

              {/* Danh sách 4 bộ câu lệnh */}
              <div className="space-y-4">
                {campaign.modelPrompts.map((mp) => (
                  <div key={mp.id} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-sm">{mp.title}</h4>
                          <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300">
                            {mp.badge}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">Tương thích tốt nhất: {mp.tool}</p>
                      </div>
                      <button
                        onClick={() => handleCopy(mp.prompt, mp.id)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold hover:opacity-90 transition"
                      >
                        {copiedId === mp.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>Sao chép câu lệnh</span>
                      </button>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl">
                      {mp.viExplain}
                    </p>

                    {/* Khung câu lệnh tiếng Anh chuẩn kỹ thuật */}
                    <div className="p-3.5 rounded-xl bg-slate-950 text-slate-100 font-mono text-xs leading-relaxed border border-slate-800 select-all">
                      {mp.prompt}
                    </div>

                    {/* 4 Thẻ phân tích yếu tố siêu thực */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-[11px]">
                      <div className="p-2.5 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900/50">
                        <span className="font-bold text-rose-700 dark:text-rose-300 block mb-0.5">Nhan sắc & Ánh mắt</span>
                        <span className="text-slate-600 dark:text-slate-300">{mp.breakdown.face}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-100 dark:border-amber-900/50">
                        <span className="font-bold text-amber-700 dark:text-amber-300 block mb-0.5">Tay & Sản phẩm</span>
                        <span className="text-slate-600 dark:text-slate-300">{mp.breakdown.hands}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/50">
                        <span className="font-bold text-emerald-700 dark:text-emerald-300 block mb-0.5">Bối cảnh đời thực</span>
                        <span className="text-slate-600 dark:text-slate-300">{mp.breakdown.scene}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50">
                        <span className="font-bold text-indigo-700 dark:text-indigo-300 block mb-0.5">Quang học & Ống kính</span>
                        <span className="text-slate-600 dark:text-slate-300">{mp.breakdown.optics}</span>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Khung Negative Prompt chặn lỗi */}
                <div className="rounded-2xl border border-rose-200 dark:border-rose-900 bg-white dark:bg-slate-900 p-5 space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-sm text-rose-600">Câu lệnh loại trừ (Negative Prompt — Chặn da nhựa & lỗi 6 ngón)</h4>
                    <button
                      onClick={() => handleCopy(campaign.negativePrompt, 'neg-prompt')}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 text-xs font-bold"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Sao chép</span>
                    </button>
                  </div>
                  <p className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 font-mono text-xs text-slate-700 dark:text-slate-300">
                    {campaign.negativePrompt}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ---------------------------------------------------------------- */}
          {/* TAB 5: CẨM NANG HƯỚNG DẪN DỰNG MẪU & GHÉP SẢN PHẨM THẬT A-Z      */}
          {/* ---------------------------------------------------------------- */}
          {activeTab === 'guide' && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-6">
              <div>
                <h3 className="font-extrabold text-lg">Quy trình 4 bước biến ảnh chụp điện thoại thành video người mẫu bán hàng</h3>
                <p className="text-xs text-slate-500 mt-1">Không cần thuê studio đắt tiền, giữ chuẩn 100% tem nhãn sản phẩm thật của shop bạn.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  {
                    step: 'Bước 1',
                    title: 'Tạo gương mặt người mẫu cố định (Character Sheet)',
                    desc: 'Dán câu lệnh Mẫu 1 hoặc Mẫu 2 vào Midjourney v6.1 hoặc Flux.1. Khi chọn được gương mặt đẹp ưng ý nhất, lưu ảnh đó lại làm ảnh gốc (--cref) để dùng xuyên suốt cho mọi bộ sưu tập của shop.'
                  },
                  {
                    step: 'Bước 2',
                    title: 'Ghép sản phẩm thật của shop vào tay người mẫu',
                    desc: 'Dùng tính năng Vary (Region) trên Midjourney hoặc Flux Inpainting: bôi vùng bàn tay người mẫu, tải ảnh chụp sản phẩm thật của shop lên để giữ nguyên từng chữ trên bao bì.'
                  },
                  {
                    step: 'Bước 3',
                    title: 'Chuyển ảnh tĩnh thành video người mẫu nói chuyện',
                    desc: 'Tải ảnh đã ghép hoàn chỉnh lên Kling AI 1.6 hoặc Runway Gen-3 (chế độ Image-to-Video), dán câu lệnh Mẫu 4 vào ô mô tả chuyển động để người mẫu chớp mắt và giới thiệu sản phẩm.'
                  },
                  {
                    step: 'Bước 4',
                    title: 'Ghép giọng đọc & Lên sóng TikTok / Shopee Video',
                    desc: 'Mở tab TikTok Từng Giây trên DựngMẫu, bật Máy nhắc chữ để tự thu âm giọng thật của bạn (hoặc dùng lồng tiếng CapCut), ghép khớp nhịp từng giây rồi đăng lên sàn.'
                  }
                ].map((item, i) => (
                  <div key={i} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-1.5">
                    <span className="inline-block px-2.5 py-0.5 rounded-md bg-indigo-600 text-white text-[11px] font-bold">
                      {item.step}
                    </span>
                    <h4 className="font-bold text-sm">{item.title}</h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      </main>

      {/* ==================================================================== */}
      {/* MODAL 1: ĐĂNG NHẬP / ĐĂNG KÝ TUÂN THỦ NGHỊ ĐỊNH 13/2023/NĐ-CP        */}
      {/* ==================================================================== */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-lg">{authMode === 'login' ? 'Đăng nhập DựngMẫu' : 'Tạo tài khoản mới'}</h3>
                <p className="text-xs text-slate-500">Bảo mật & lưu trữ dữ liệu tuân thủ pháp luật Việt Nam</p>
              </div>
              <button onClick={() => setShowAuthModal(false)} className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Chuyển Tab Đăng nhập / Đăng ký */}
            <div className="grid grid-cols-2 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold">
              <button
                type="button"
                onClick={() => { setAuthMode('login'); setAuthError(''); }}
                className={`py-2 rounded-lg transition ${authMode === 'login' ? 'bg-white dark:bg-slate-900 shadow-sm' : 'text-slate-500'}`}
              >
                Đăng nhập
              </button>
              <button
                type="button"
                onClick={() => { setAuthMode('register'); setAuthError(''); }}
                className={`py-2 rounded-lg transition ${authMode === 'register' ? 'bg-white dark:bg-slate-900 shadow-sm' : 'text-slate-500'}`}
              >
                Đăng ký mới (+5 lượt)
              </button>
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 font-medium flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{authError}</span>
              </div>
            )}

            <form onSubmit={handleAuthSubmit} className="space-y-3">
              {authMode === 'register' && (
                <div>
                  <label className="block text-xs font-semibold mb-1">Họ tên hoặc Tên Cửa hàng *</label>
                  <input
                    type="text"
                    value={authForm.fullName}
                    onChange={(e) => setAuthForm({ ...authForm, fullName: e.target.value })}
                    placeholder="VD: Nguyễn Minh Anh - Shop Gia Dụng"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold mb-1">Email hoặc Số điện thoại Việt Nam *</label>
                <input
                  type="text"
                  value={authForm.identifier}
                  onChange={(e) => setAuthForm({ ...authForm, identifier: e.target.value })}
                  placeholder="VD: shopcuaban@gmail.com hoặc 0912345678"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Mật khẩu (tối thiểu 8 ký tự) *</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={authForm.password}
                    onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })}
                    placeholder="Nhập mật khẩu bảo mật..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {/* Thanh đo độ mạnh mật khẩu khi đăng ký */}
                {authMode === 'register' && authForm.password.length > 0 && (
                  <div className="mt-1.5 space-y-1">
                    <div className="grid grid-cols-4 gap-1 h-1.5">
                      {[1, 2, 3, 4].map((lvl) => (
                        <div
                          key={lvl}
                          className={`rounded-full ${
                            passwordStrength >= lvl
                              ? passwordStrength <= 1
                                ? 'bg-rose-500'
                                : passwordStrength <= 2
                                ? 'bg-amber-500'
                                : 'bg-emerald-500'
                              : 'bg-slate-200 dark:bg-slate-700'
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Độ mạnh: {passwordStrength <= 1 ? 'Yếu' : passwordStrength === 2 ? 'Trung bình' : passwordStrength === 3 ? 'Tốt' : 'Rất mạnh'}
                    </p>
                  </div>
                )}
              </div>

              {/* Hộp kiểm đồng ý chủ thể dữ liệu theo Nghị định 13/2023/NĐ-CP (Không tích sẵn) */}
              {authMode === 'register' && (
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-1.5">
                  <label className="flex items-start gap-2.5 cursor-pointer text-xs leading-relaxed">
                    <input
                      type="checkbox"
                      checked={authForm.consentAccepted}
                      onChange={(e) => setAuthForm({ ...authForm, consentAccepted: e.target.checked })}
                      className="mt-1 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>
                      Tôi đã đọc và tự nguyện đồng ý cho <strong>{BRAND.name}</strong> xử lý dữ liệu cá nhân (Email/SĐT, lịch sử kịch bản) nhằm cung cấp dịch vụ theo{' '}
                      <button
                        type="button"
                        onClick={() => setShowPrivacyDoc(true)}
                        className="text-indigo-600 font-bold underline"
                      >
                        Chính sách Bảo vệ Dữ liệu Cá nhân (Nghị định 13/2023/NĐ-CP)
                      </button>.
                    </span>
                  </label>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md transition"
              >
                {authMode === 'login' ? 'Đăng nhập an toàn' : 'Hoàn tất đăng ký'}
              </button>
            </form>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-center">
              <button
                type="button"
                onClick={handleQuickDemoProLogin}
                className="text-xs font-bold text-emerald-600 hover:underline"
              >
                Hoặc dùng ngay Tài khoản Demo Pro (Không cần nhập liệu) →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL 2: CHÍNH SÁCH BẢO VỆ DỮ LIỆU CÁ NHÂN (NĐ 13/2023/NĐ-CP)        */}
      {/* ==================================================================== */}
      {showPrivacyDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <span>Chính sách Bảo vệ Dữ liệu Cá nhân (NĐ 13/2023/NĐ-CP)</span>
              </h3>
              <button onClick={() => setShowPrivacyDoc(false)} className="p-1.5 rounded-lg hover:bg-slate-100">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-300 space-y-2.5 leading-relaxed">
              <p><strong>1. Mục đích xử lý dữ liệu:</strong> DựngMẫu chỉ thu thập Email/Số điện thoại và nội dung mô tả sản phẩm do bạn chủ động nhập để định danh tài khoản, đồng bộ lịch sử kịch bản và kích hoạt gói dịch vụ.</p>
              <p><strong>2. Lưu trữ dữ liệu tại Việt Nam (Luật An ninh mạng):</strong> Toàn bộ dữ liệu định danh người dùng Việt Nam được mã hóa đường truyền TLS 1.3, mã hóa mật khẩu Argon2id và lưu trữ tại trung tâm dữ liệu đặt tại lãnh thổ Việt Nam.</p>
              <p><strong>3. Cam kết không chia sẻ trái phép:</strong> Chúng tôi tuyệt đối không bán, cho thuê hoặc chia sẻ danh sách sản phẩm, kịch bản kinh doanh của chủ shop cho bất kỳ bên thứ ba nào.</p>
              <p><strong>4. Quyền của chủ thể dữ liệu:</strong> Bạn có toàn quyền truy cập, tải về toàn bộ dữ liệu cá nhân định dạng JSON, rút lại sự đồng ý hoặc yêu cầu xóa vĩnh viễn tài khoản ngay trong mục <em>Trung tâm Tài khoản & Bảo mật</em>.</p>
            </div>
            <button
              onClick={() => setShowPrivacyDoc(false)}
              className="w-full py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold"
            >
              Đã hiểu
            </button>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL 3: TRUNG TÂM TÀI KHOẢN & QUYỀN RIÊNG TƯ (NĐ 13/2023/NĐ-CP)     */}
      {/* ==================================================================== */}
      {showAccountCenter && currentUser && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-2xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 flex items-center justify-center font-extrabold text-base">
                  {currentUser.fullName.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-extrabold text-base">{currentUser.fullName}</h3>
                  <p className="text-xs text-slate-500">{currentUser.identifier} • Máy chủ lưu trữ: {currentUser.dataRegion}</p>
                </div>
              </div>
              <button onClick={() => setShowAccountCenter(false)} className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Trạng thái bảo mật & 2FA */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold flex items-center gap-1.5">
                    <KeyRound className="w-4 h-4 text-indigo-600" /> Xác thực 2 lớp (2FA)
                  </span>
                  <button
                    onClick={() => {
                      setCurrentUser((u) => ({ ...u, twoFactorEnabled: !u.twoFactorEnabled }));
                      notify('Đã cập nhật trạng thái bảo mật 2 lớp!');
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                      currentUser.twoFactorEnabled ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {currentUser.twoFactorEnabled ? 'Đang bật' : 'Bật ngay'}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">Bảo vệ tài khoản khỏi đăng nhập trái phép từ thiết bị lạ.</p>
              </div>

              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                <span className="text-xs font-bold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" /> Trạng thái pháp lý Dữ liệu
                </span>
                <p className="text-[11px] text-slate-500">
                  Phiên bản đồng ý: <strong>{currentUser.consentVersion}</strong> lúc {currentUser.consentedAt}
                </p>
              </div>
            </div>

            {/* Thực thi quyền chủ thể dữ liệu theo Nghị định 13/2023/NĐ-CP */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
              <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                Quyền dữ liệu cá nhân của bạn (Nghị định 13/2023/NĐ-CP)
              </h4>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={handleExportPersonalData}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold hover:border-indigo-500 transition"
                >
                  <Download className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Xuất toàn bộ dữ liệu cá nhân (.JSON)</span>
                </button>
                <button
                  onClick={() => setShowPrivacyDoc(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  <FileText className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Xem văn bản đồng ý</span>
                </button>
              </div>

              {/* Vùng xóa vĩnh viễn tài khoản */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-700 space-y-2">
                <p className="text-xs font-bold text-rose-600">Xóa vĩnh viễn tài khoản & toàn bộ dữ liệu ("Quyền được lãng quên")</p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={deleteConfirmText}
                    onChange={(e) => setDeleteConfirmText(e.target.value)}
                    placeholder="Gõ XOA TAI KHOAN để xác nhận..."
                    className="flex-1 px-3 py-2 rounded-xl border border-rose-200 dark:border-rose-900 bg-white dark:bg-slate-900 text-xs"
                  />
                  <button
                    onClick={handlePermanentDeleteAccount}
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shrink-0"
                  >
                    Xóa vĩnh viễn
                  </button>
                </div>
              </div>
            </div>

            {/* Nhật ký bảo mật */}
            <div className="space-y-2">
              <h4 className="font-bold text-xs text-slate-500">Nhật ký hoạt động bảo mật gần đây (Lưu trữ theo Luật An ninh mạng)</h4>
              <div className="max-h-32 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl px-3">
                {(currentUser.auditLogs || []).map((log, i) => (
                  <div key={i} className="py-2 flex items-center justify-between text-[11px]">
                    <span className="font-medium">{log.action}</span>
                    <span className="text-slate-400 font-mono">{log.time}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => {
                  setCurrentUser(null);
                  setShowAccountCenter(false);
                  notify('Đã đăng xuất an toàn!');
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-rose-600 hover:bg-rose-50"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Đăng xuất khỏi thiết bị này</span>
              </button>
              <button
                onClick={() => setShowAccountCenter(false)}
                className="px-5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL 4: BẢNG GIÁ 4 GÓI & THANH TOÁN VIETQR TỰ ĐỘNG                   */}
      {/* ==================================================================== */}
      {showPricingModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/65 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-5xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-5 max-h-[92vh] overflow-y-auto">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-extrabold text-xl">Nâng cấp gói {BRAND.name} — Đầu tư nhỏ, chốt đơn lớn</h3>
                <p className="text-xs text-slate-500">Chi phí rẻ hơn 1 buổi thuê mẫu chụp ảnh, dùng trọn bộ cho cả cửa hàng.</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold">
                  <button
                    onClick={() => setBillingCycle('monthly')}
                    className={`px-3 py-1.5 rounded-lg ${billingCycle === 'monthly' ? 'bg-white dark:bg-slate-900 shadow-sm' : 'text-slate-500'}`}
                  >
                    Theo tháng
                  </button>
                  <button
                    onClick={() => setBillingCycle('yearly')}
                    className={`px-3 py-1.5 rounded-lg ${billingCycle === 'yearly' ? 'bg-white dark:bg-slate-900 shadow-sm text-emerald-600' : 'text-slate-500'}`}
                  >
                    Theo năm (-25%)
                  </button>
                </div>
                <button onClick={() => setShowPricingModal(false)} className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* 4 Thẻ gói cước */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {Object.values(PLANS).map((p) => {
                const price = billingCycle === 'yearly' ? p.priceYearly : p.priceMonthly;
                const isSelected = selectedUpgradePlan === p.id;
                return (
                  <div
                    key={p.id}
                    onClick={() => p.id !== 'FREE' && setSelectedUpgradePlan(p.id)}
                    className={`cursor-pointer rounded-2xl p-4 border-2 transition flex flex-col justify-between space-y-4 ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/30 dark:bg-indigo-950/20 shadow-md'
                        : 'border-slate-200 dark:border-slate-800 hover:border-indigo-300'
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-extrabold px-2 py-0.5 rounded-full bg-slate-900 text-white dark:bg-white dark:text-slate-900">
                          {p.badge}
                        </span>
                        {p.popular && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                            Phổ biến nhất
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-base">{p.name}</h4>
                      <div className="text-2xl font-extrabold">
                        {price === 0 ? '0đ' : `${price.toLocaleString('vi-VN')}đ`}
                        {price > 0 && <span className="text-xs font-normal text-slate-400">/{p.id === 'STARTER' ? '25 lượt' : 'tháng'}</span>}
                      </div>
                      <p className="text-xs text-slate-500 leading-relaxed">{p.desc}</p>
                    </div>

                    <div className="space-y-1.5 text-xs pt-2 border-t border-slate-100 dark:border-slate-800">
                      <div className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>{p.credits >= 9999 ? 'Không giới hạn lượt tạo' : `${p.credits} lượt tạo chiến dịch`}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>Kịch bản dài tới {p.maxDuration} giây</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>Mở 100% 4 lệnh Người mẫu thật</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Khu vực thanh toán qua Cổng thanh toán SePay Payment Gateway (sepay-pg-node) */}
            {selectedUpgradePlan !== 'FREE' && (
              <div className="rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="space-y-1.5 text-xs">
                  <span className="inline-block px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                    Cổng thanh toán bảo mật SePay Payment Gateway (BANK_TRANSFER)
                  </span>
                  <h4 className="font-bold text-sm">
                    Gói đang chọn: {PLANS[selectedUpgradePlan].name} —{' '}
                    {(billingCycle === 'yearly' ? PLANS[selectedUpgradePlan].priceYearly : PLANS[selectedUpgradePlan].priceMonthly).toLocaleString('vi-VN')}đ
                  </h4>
                  <p className="text-slate-500">
                    Hệ thống tự động tạo chữ ký đơn hàng trên Server, chuyển sang trang thanh toán VietQR của SePay và tự động mở khóa gói ngay khi hoàn tất.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handleProceedSePayCheckout}
                    disabled={sepayLoading}
                    className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md transition disabled:opacity-60"
                  >
                    {sepayLoading ? 'Đang kết nối SePay...' : 'Thanh toán ngay qua SePay'}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleActivatePlan(selectedUpgradePlan)}
                    className="px-3.5 py-3 rounded-xl border border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 text-xs font-bold transition"
                  >
                    Kích hoạt test nhanh
                  </button>
                </div>

                {/* Form POST ẩn nhận checkoutURL & checkoutFormfields từ sepay-pg-node */}
                {sepayCheckoutData && (
                  <form ref={sepayFormRef} action={sepayCheckoutData.checkoutURL} method="POST" className="hidden">
                    {Object.keys(sepayCheckoutData.checkoutFormfields || {}).map((field) => (
                      <input
                        key={field}
                        type="hidden"
                        name={field}
                        value={sepayCheckoutData.checkoutFormfields[field]}
                      />
                    ))}
                  </form>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL 5: MÁY NHẮC CHỮ TỰ ĐỘNG KHỚP TỪNG GIÂY (TELEPROMPTER)          */}
      {/* ==================================================================== */}
      {showTeleprompter && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 text-white">
          <div className="w-full max-w-2xl rounded-3xl bg-slate-900 border border-slate-800 p-6 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Máy nhắc chữ Đạo diễn • Phân cảnh {tpSceneIdx + 1}/{currentScriptScenes.length}
                </span>
              </div>
              <button onClick={() => { setTpPlaying(false); setShowTeleprompter(false); }} className="p-2 rounded-xl hover:bg-slate-800">
                <X className="w-5 h-5" />
              </button>
            </div>

            {currentScriptScenes[tpSceneIdx] && (
              <div className="space-y-4 text-center py-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-bold">
                  <span>{currentScriptScenes[tpSceneIdx].time}</span>
                  <span>•</span>
                  <span>{tpElapsed}s / {currentScriptScenes[tpSceneIdx].sec}s</span>
                </div>

                <p className="text-2xl sm:text-3xl font-extrabold leading-snug text-white">
                  “{currentScriptScenes[tpSceneIdx].voice}”
                </p>

                <p className="text-xs text-amber-300 bg-amber-950/50 inline-block px-3 py-1.5 rounded-xl">
                  Hành động: {currentScriptScenes[tpSceneIdx].action}
                </p>

                {/* Cảnh báo giới hạn 2 cảnh ở gói Free */}
                {!activePlan.allowFullTeleprompter && tpSceneIdx >= 1 && (
                  <div className="p-3 rounded-xl bg-indigo-950 border border-indigo-700 text-xs space-y-2">
                    <p>Gói Miễn phí hỗ trợ chạy thử 2 cảnh đầu. Nâng cấp gói <strong>Starter (79.000đ)</strong> để chạy trọn bộ kịch bản không ngắt quãng.</p>
                    <button
                      onClick={() => { setShowTeleprompter(false); setSelectedUpgradePlan('STARTER'); setShowPricingModal(true); }}
                      className="px-4 py-1.5 rounded-lg bg-indigo-600 text-white font-bold"
                    >
                      Mở khóa Máy nhắc chữ Full
                    </button>
                  </div>
                )}
              </div>
            )}

            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => { setTpSceneIdx(0); setTpElapsed(0); setTpPlaying(true); }}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold flex items-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" /> Từ đầu
              </button>
              <button
                onClick={() => setTpPlaying(!tpPlaying)}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-xs font-bold flex items-center gap-1.5"
              >
                {tpPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{tpPlaying ? 'Tạm dừng' : 'Tiếp tục chạy'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* DRAWER LỊCH SỬ CHIẾN DỊCH ĐÃ LƯU                                     */}
      {/* ==================================================================== */}
      {showHistoryDrawer && (
        <div className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 h-full p-5 shadow-2xl border-l border-slate-200 dark:border-slate-800 flex flex-col justify-between">
            <div className="space-y-4 overflow-y-auto">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="font-bold text-base">Lịch sử đã dựng ({history.length}/{activePlan.maxHistory})</h3>
                <button onClick={() => setShowHistoryDrawer(false)} className="p-1.5 rounded-lg hover:bg-slate-100">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {history.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-10">Chưa có chiến dịch nào được lưu.</p>
              ) : (
                <div className="space-y-2.5">
                  {history.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => { setCampaign(item); setShowHistoryDrawer(false); notify('Đã khôi phục kịch bản!'); }}
                      className="cursor-pointer p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-500 transition space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs truncate max-w-[240px]">{item.productName}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-600 font-bold">
                          {item.duration}s
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">{item.category} • {item.createdAt}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {history.length > 0 && (
              <button
                onClick={() => { setHistory([]); notify('Đã xóa sạch lịch sử!'); }}
                className="w-full py-2.5 rounded-xl border border-rose-200 text-rose-600 text-xs font-bold hover:bg-rose-50 flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" /> Xóa toàn bộ lịch sử
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
