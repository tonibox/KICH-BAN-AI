# HƯỚNG DẪN CẤU HÌNH SEPAY PAYMENT GATEWAY (`sepay-pg-node`) CHO DỰNGMẪU

## 1. Kiến trúc bảo mật đã tích hợp sẵn
Đoạn mã `SePayPgClient` của bạn sử dụng `secret_key` để ký dữ liệu đơn hàng (`initOneTimePaymentFields`). Vì lý do bảo mật tuyệt đối (không để lộ `secret_key` trên trình duyệt F12), dự án đã tách chuẩn thành 2 lớp:
- **Backend API (`/api/sepay/create-checkout.js`):** Nhận `planId` và `billingCycle`, dùng `sepay-pg-node` khởi tạo `checkoutURL` cùng `checkoutFormfields` có chữ ký hợp lệ và trả về cho Frontend.
- **Backend IPN (`/api/sepay/ipn.js`):** Nhận thông báo thanh toán ngầm từ SePay và xác thực chữ ký HMAC-SHA256.
- **Frontend (`src/App.jsx`):** Khi khách bấm **"Thanh toán ngay qua SePay"**, ứng dụng gọi `/api/sepay/create-checkout`, điền vào `<form action={checkoutURL} method="POST">` ẩn và tự động gửi sang trang thanh toán của SePay. Khi thanh toán xong, SePay chuyển hướng khách về `success_url` (`/?payment=success&plan=...`) và ứng dụng tự động mở khóa gói cước ngay lập tức.

## 2. Cách điền `merchant_id` và `secret_key` để chạy thật
1. Cài đặt gói thư viện (đã khai báo sẵn trong `package.json`):
   ```bash
   npm install
   ```
2. Sao chép tệp `.env.example` thành `.env` (khi chạy trên máy) hoặc khai báo trong **Vercel -> Project Settings -> Environment Variables**:
   - `SEPAY_ENV` = `sandbox` (khi test) hoặc `production` (khi thu tiền thật)
   - `SEPAY_MERCHANT_ID` = Mã Merchant ID lấy từ trang quản trị SePay
   - `SEPAY_SECRET_KEY` = Mã Secret Key lấy từ trang quản trị SePay
   - `APP_BASE_URL` = `https://dungmau.vn` (hoặc link Vercel của bạn)
3. Chạy thử toàn bộ cả Frontend lẫn Backend Serverless API trên máy bằng lệnh:
   ```bash
   npx vercel dev
   ```
