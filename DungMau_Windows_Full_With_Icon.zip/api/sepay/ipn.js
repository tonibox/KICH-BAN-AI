import crypto from 'crypto';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method Not Allowed' });
  }

  try {
    const secretKey = process.env.SEPAY_SECRET_KEY || '';
    const payload = req.body || {};

    // Xác thực chữ ký bảo mật từ SePay IPN (nếu SePay gửi kèm signature)
    if (payload.signature && secretKey) {
      const { signature, ...restFields } = payload;
      const sortedData = Object.keys(restFields)
        .sort()
        .map((k) => `${k}=${restFields[k]}`)
        .join('&');
      const expectedSig = crypto.createHmac('sha256', secretKey).update(sortedData).digest('hex');
      if (signature !== expectedSig) {
        return res.status(401).json({ success: false, message: 'Chữ ký IPN không hợp lệ' });
      }
    }

    const invoice = String(payload.order_invoice_number || '');
    const status = String(payload.order_status || payload.status || '').toUpperCase();

    if (status === 'CAPTURED' || status === 'PAID' || status === 'SUCCESS') {
      // TODO (Production DB): Cập nhật trạng thái gói cước của user trong Firestore / PostgreSQL theo invoice
      console.log(`[SePay IPN] Đã xác nhận thanh toán thành công đơn hàng: ${invoice}`);
    }

    return res.status(200).json({ success: true });
  } catch (error) {
    console.error('[SePay IPN Error]:', error);
    return res.status(500).json({ success: false });
  }
}
