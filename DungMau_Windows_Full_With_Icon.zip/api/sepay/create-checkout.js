import { SePayPgClient } from 'sepay-pg-node';

// Bảng giá chuẩn xác thực ở Server (Chống giả mạo số tiền từ trình duyệt)
const PLAN_PRICING = {
  STARTER: { monthly: 79000, yearly: 59000, label: 'Goi Chu Shop Nho (STARTER)' },
  PRO: { monthly: 199000, yearly: 149000, label: 'Goi Dao Dien Ban Hang (PRO)' },
  AGENCY: { monthly: 499000, yearly: 379000, label: 'Goi Chuoi Shop & Studio (AGENCY)' }
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const { planId, billingCycle = 'monthly', userId = 'GUEST' } = req.body || {};
    const planConfig = PLAN_PRICING[planId];
    if (!planConfig) {
      return res.status(400).json({ error: 'Gói dịch vụ không hợp lệ.' });
    }

    const merchantId = process.env.SEPAY_MERCHANT_ID;
    const secretKey = process.env.SEPAY_SECRET_KEY;
    const env = (process.env.SEPAY_ENV === 'production' || String(merchantId).startsWith('SP-LIVE-')) ? 'production' : 'sandbox';

    if (!merchantId || !secretKey || merchantId === 'YOUR_MERCHANT_ID') {
      return res.status(503).json({
        error: 'Chưa cấu hình SEPAY_MERCHANT_ID hoặc SEPAY_SECRET_KEY trong biến môi trường server.',
        demoFallback: true
      });
    }

    const client = new SePayPgClient({
      env,
      merchant_id: merchantId,
      secret_key: secretKey
    });

    const amount = billingCycle === 'yearly' ? planConfig.yearly : planConfig.monthly;
    const cleanUser = String(userId).replace(/[^a-zA-Z0-9]/g, '').slice(-8).toUpperCase() || 'GUEST';
    const invoiceNumber = `DM_${planId}_${cleanUser}_${Date.now()}`;

    const baseUrl = (process.env.APP_BASE_URL || `https://${req.headers.host}`).replace(/\/$/, '');
    const checkoutURL = client.checkout.initCheckoutUrl();

    const checkoutFormfields = client.checkout.initOneTimePaymentFields({
      payment_method: 'BANK_TRANSFER',
      order_invoice_number: invoiceNumber,
      order_amount: amount,
      currency: 'VND',
      order_description: `Thanh toan ${planConfig.label} - ${invoiceNumber}`,
      success_url: `${baseUrl}/?payment=success&plan=${planId}&invoice=${encodeURIComponent(invoiceNumber)}`,
      error_url: `${baseUrl}/?payment=error&plan=${planId}&invoice=${encodeURIComponent(invoiceNumber)}`,
      cancel_url: `${baseUrl}/?payment=cancel&plan=${planId}&invoice=${encodeURIComponent(invoiceNumber)}`
    });

    return res.status(200).json({
      checkoutURL,
      checkoutFormfields,
      invoiceNumber,
      amount
    });
  } catch (err) {
    console.error('[SePay Checkout Error]:', err);
    return res.status(500).json({ error: 'Không thể khởi tạo phiên thanh toán SePay.' });
  }
}
